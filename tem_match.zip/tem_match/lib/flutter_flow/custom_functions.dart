import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

List<String> getOnlyRepeatedString(
  List<String> var1,
  List<String> var2,
) {
  final List<String> list = [];
  for (var v in var1) {
    if (var2.contains(v)) list.add(v);
  }
  return list;
}

DateTime? dateIgnore() {
  final DateTime now = DateTime.now();
  return now.subtract(Duration(days: 1));
}

ActivityBranchesRecord? getActivityBranches(
  List<ActivityBranchesRecord> activityBranches,
  String? docId,
) {
  if (docId?.isEmpty ?? true) return null;

  for (var ab in activityBranches) {
    if (ab.reference.id == docId) {
      return ab;
    }
  }
}

AddressesRecord? getAddress(
  List<AddressesRecord> addresses,
  String? docId,
) {
  if (docId?.isEmpty ?? true) return null;

  for (var address in addresses) {
    if (address.reference.id == docId) {
      return address;
    }
  }
}

DateTime today() {
  final DateTime dt = DateTime.now();
  return DateTime(dt.year, dt.month, dt.day);
}

bool smLimit(List<MatchRecord> matches) {
  bool ok = true;

  for (var match in matches) {
    if (match.createdAt != null &&
        match.createdAt!.millisecondsSinceEpoch >
            today().millisecondsSinceEpoch) {
    } else {
      ok = false;
      break;
    }
  }

  return (matches.length <= 1) ? true : !ok;
}

bool filterUser(
  List<String> tags2,
  List<String> ignore,
  UsersRecord otherUser,
  String? acitivityBranchID,
  String? faseStartupID,
  String? valuationStartupID,
  String? question1,
  String? question2,
  String? question3,
) {
  bool ok0 = false;
  bool ok1 = false;
  bool ok2 = false;
  bool ok3 = false;
  bool ok4 = false;
  bool ok5 = false;
  bool ok6 = false;

  if (ignore.contains(otherUser.uid)) return false;

  if (tags2.length >= 0) {
    for (var tag1 in otherUser.tags1) {
      if (tags2.contains(tag1)) {
        ok0 = true;
      }
    }
  } else {
    ok0 = true;
  }

  if ((acitivityBranchID?.isNotEmpty ?? false) &&
      otherUser.hasActivityBranch()) {
    if (otherUser.activityBranch!.id == acitivityBranchID) {
      ok1 = true;
    }
  } else {
    ok1 = true;
  }

  if ((faseStartupID?.isNotEmpty ?? false) && otherUser.hasFaseStartup()) {
    if (otherUser.faseStartup!.id == faseStartupID) {
      ok2 = true;
    }
  } else {
    ok2 = true;
  }

  if ((valuationStartupID?.isNotEmpty ?? false) &&
      otherUser.hasValuationStartup()) {
    if (otherUser.valuationStartup!.id == valuationStartupID) {
      ok3 = true;
    }
  } else {
    ok3 = true;
  }

  if ((question1?.isNotEmpty ?? false) && otherUser.hasQuestion1()) {
    if (otherUser.question1!.id == question1) {
      ok4 = true;
    }
  } else {
    ok4 = true;
  }

  if ((question2?.isNotEmpty ?? false) && otherUser.hasQuestion2()) {
    if (otherUser.question2!.id == question2) {
      ok5 = true;
    }
  } else {
    ok5 = true;
  }

  if ((question3?.isNotEmpty ?? false) && otherUser.hasQuestion3()) {
    if (otherUser.question3!.id == question3) {
      ok6 = true;
    }
  } else {
    ok6 = true;
  }

  if (ok0 && ok1 && ok2 && ok3 && ok4 && ok5 && ok6) return true;

  return false;
}
