import 'dart:async';

import 'serialization_util.dart';
import '../backend.dart';
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';


final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({super.key, required this.child});

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    if (mounted) {
      setState(() => _loading = true);
    }
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        context.pushNamed(
          initialPageName,
          pathParameters: parameterData.pathParameters,
          extra: parameterData.extra,
        );
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  void initState() {
    super.initState();
    handleOpenedPushNotification();
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Container(
          color: FlutterFlowTheme.of(context).accent1,
          child: Center(
            child: Image.asset(
              'assets/images/Design_sem_nome_(20).png',
              width: double.infinity,
              height: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => const ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'HomePage': ParameterData.none(),
  'SignInPage': (data) async => ParameterData(
        allParams: {
          'email': getParameter<String>(data, 'email'),
        },
      ),
  'WelcomePage': ParameterData.none(),
  'SignUpPage': (data) async => ParameterData(
        allParams: {
          'email': getParameter<String>(data, 'email'),
        },
      ),
  'ProfilePage': ParameterData.none(),
  'SetUserSidePage': ParameterData.none(),
  'ForgotPassword': (data) async => ParameterData(
        allParams: {
          'email': getParameter<String>(data, 'email'),
        },
      ),
  'SettingsPage': ParameterData.none(),
  'NotificationPage': ParameterData.none(),
  'NotificationsSettingsPage': ParameterData.none(),
  'TermsAndPrivacyPage': (data) async => ParameterData(
        allParams: {
          'mandatoryToAgree': getParameter<bool>(data, 'mandatoryToAgree'),
        },
      ),
  'EditProfilePage': (data) async => ParameterData(
        allParams: {
          'first': getParameter<bool>(data, 'first'),
        },
      ),
  'ResetPasswordPage': ParameterData.none(),
  'ChangeEmailPage': ParameterData.none(),
  'AccountPage': ParameterData.none(),
  'PhoneNumberPage': ParameterData.none(),
  'SupportPage': ParameterData.none(),
  'ReportPage': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
        },
      ),
  'UserInfoPage': (data) async => ParameterData(
        allParams: {
          'user': await getDocumentParameter<UsersRecord>(
              data, 'user', UsersRecord.fromSnapshot),
          'address': await getDocumentParameter<AddressesRecord>(
              data, 'address', AddressesRecord.fromSnapshot),
          'activityBranch': await getDocumentParameter<ActivityBranchesRecord>(
              data, 'activityBranch', ActivityBranchesRecord.fromSnapshot),
        },
      ),
  'ChatPage': (data) async => ParameterData(
        allParams: {
          'chatUser': await getDocumentParameter<UsersRecord>(
              data, 'chatUser', UsersRecord.fromSnapshot),
          'chatRef': getParameter<DocumentReference>(data, 'chatRef'),
        },
      ),
  'AllChatsPage': ParameterData.none(),
  'AddChatUsersPage': ParameterData.none(),
  'DashboardPage': ParameterData.none(),
  'Tags1Page': (data) async => ParameterData(
        allParams: {
          'firstDefinition': getParameter<bool>(data, 'firstDefinition'),
        },
      ),
  'Tags2Page': (data) async => ParameterData(
        allParams: {
          'firstDefinition': getParameter<bool>(data, 'firstDefinition'),
        },
      ),
  'FIlterPage': ParameterData.none(),
  'WelcomeManagementPage': ParameterData.none(),
  'ReportsPage': ParameterData.none(),
  'FAQsPage': ParameterData.none(),
  'AdsPage': ParameterData.none(),
  'AnswerBankPage': ParameterData.none(),
  'AddAdsPage': (data) async => ParameterData(
        allParams: {
          'ad': await getDocumentParameter<AdvertsRecord>(
              data, 'ad', AdvertsRecord.fromSnapshot),
        },
      ),
  'ShowUsersPage': (data) async => ParameterData(
        allParams: {
          'title': getParameter<String>(data, 'title'),
        },
      ),
  'ADMsPage': ParameterData.none(),
  'DeleteAccountPage': ParameterData.none(),
  'BannedUserPage': ParameterData.none(),
  'TermsEULAPage': (data) async => ParameterData(
        allParams: {
          'mandatoryToAgree': getParameter<bool>(data, 'mandatoryToAgree'),
        },
      ),
  'EditTagPage': ParameterData.none(),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
