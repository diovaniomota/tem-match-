import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class Question3Record extends FirestoreRecord {
  Question3Record._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('question_3');

  static Stream<Question3Record> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Question3Record.fromSnapshot(s));

  static Future<Question3Record> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Question3Record.fromSnapshot(s));

  static Question3Record fromSnapshot(DocumentSnapshot snapshot) =>
      Question3Record._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Question3Record getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Question3Record._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Question3Record(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Question3Record &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createQuestion3RecordData({
  String? name,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
    }.withoutNulls,
  );

  return firestoreData;
}

class Question3RecordDocumentEquality implements Equality<Question3Record> {
  const Question3RecordDocumentEquality();

  @override
  bool equals(Question3Record? e1, Question3Record? e2) {
    return e1?.name == e2?.name;
  }

  @override
  int hash(Question3Record? e) => const ListEquality().hash([e?.name]);

  @override
  bool isValidKey(Object? o) => o is Question3Record;
}
