import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class ViewsAdRecord extends FirestoreRecord {
  ViewsAdRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "viewer" field.
  DocumentReference? _viewer;
  DocumentReference? get viewer => _viewer;
  bool hasViewer() => _viewer != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _createdAt = snapshotData['created_at'] as DateTime?;
    _viewer = snapshotData['viewer'] as DocumentReference?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('views_ad')
          : FirebaseFirestore.instance.collectionGroup('views_ad');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('views_ad').doc(id);

  static Stream<ViewsAdRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ViewsAdRecord.fromSnapshot(s));

  static Future<ViewsAdRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ViewsAdRecord.fromSnapshot(s));

  static ViewsAdRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ViewsAdRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ViewsAdRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ViewsAdRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ViewsAdRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ViewsAdRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createViewsAdRecordData({
  DateTime? createdAt,
  DocumentReference? viewer,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_at': createdAt,
      'viewer': viewer,
    }.withoutNulls,
  );

  return firestoreData;
}

class ViewsAdRecordDocumentEquality implements Equality<ViewsAdRecord> {
  const ViewsAdRecordDocumentEquality();

  @override
  bool equals(ViewsAdRecord? e1, ViewsAdRecord? e2) {
    return e1?.createdAt == e2?.createdAt && e1?.viewer == e2?.viewer;
  }

  @override
  int hash(ViewsAdRecord? e) =>
      const ListEquality().hash([e?.createdAt, e?.viewer]);

  @override
  bool isValidKey(Object? o) => o is ViewsAdRecord;
}
