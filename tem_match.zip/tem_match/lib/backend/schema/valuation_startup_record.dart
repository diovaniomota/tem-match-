import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class ValuationStartupRecord extends FirestoreRecord {
  ValuationStartupRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('valuation_startup');

  static Stream<ValuationStartupRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ValuationStartupRecord.fromSnapshot(s));

  static Future<ValuationStartupRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => ValuationStartupRecord.fromSnapshot(s));

  static ValuationStartupRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ValuationStartupRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ValuationStartupRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ValuationStartupRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ValuationStartupRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ValuationStartupRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createValuationStartupRecordData({
  String? name,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
    }.withoutNulls,
  );

  return firestoreData;
}

class ValuationStartupRecordDocumentEquality
    implements Equality<ValuationStartupRecord> {
  const ValuationStartupRecordDocumentEquality();

  @override
  bool equals(ValuationStartupRecord? e1, ValuationStartupRecord? e2) {
    return e1?.name == e2?.name;
  }

  @override
  int hash(ValuationStartupRecord? e) => const ListEquality().hash([e?.name]);

  @override
  bool isValidKey(Object? o) => o is ValuationStartupRecord;
}
