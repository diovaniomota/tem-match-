import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class MatchRecord extends FirestoreRecord {
  MatchRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "sender" field.
  DocumentReference? _sender;
  DocumentReference? get sender => _sender;
  bool hasSender() => _sender != null;

  // "recipient" field.
  DocumentReference? _recipient;
  DocumentReference? get recipient => _recipient;
  bool hasRecipient() => _recipient != null;

  // "is_super" field.
  bool? _isSuper;
  bool get isSuper => _isSuper ?? false;
  bool hasIsSuper() => _isSuper != null;

  void _initializeFields() {
    _createdAt = snapshotData['created_at'] as DateTime?;
    _sender = snapshotData['sender'] as DocumentReference?;
    _recipient = snapshotData['recipient'] as DocumentReference?;
    _isSuper = snapshotData['is_super'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('match');

  static Stream<MatchRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MatchRecord.fromSnapshot(s));

  static Future<MatchRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MatchRecord.fromSnapshot(s));

  static MatchRecord fromSnapshot(DocumentSnapshot snapshot) => MatchRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MatchRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MatchRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MatchRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MatchRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMatchRecordData({
  DateTime? createdAt,
  DocumentReference? sender,
  DocumentReference? recipient,
  bool? isSuper,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_at': createdAt,
      'sender': sender,
      'recipient': recipient,
      'is_super': isSuper,
    }.withoutNulls,
  );

  return firestoreData;
}

class MatchRecordDocumentEquality implements Equality<MatchRecord> {
  const MatchRecordDocumentEquality();

  @override
  bool equals(MatchRecord? e1, MatchRecord? e2) {
    return e1?.createdAt == e2?.createdAt &&
        e1?.sender == e2?.sender &&
        e1?.recipient == e2?.recipient &&
        e1?.isSuper == e2?.isSuper;
  }

  @override
  int hash(MatchRecord? e) => const ListEquality()
      .hash([e?.createdAt, e?.sender, e?.recipient, e?.isSuper]);

  @override
  bool isValidKey(Object? o) => o is MatchRecord;
}
