import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class AdvertsRecord extends FirestoreRecord {
  AdvertsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "end_date" field.
  DateTime? _endDate;
  DateTime? get endDate => _endDate;
  bool hasEndDate() => _endDate != null;

  // "link" field.
  String? _link;
  String get link => _link ?? '';
  bool hasLink() => _link != null;

  // "media_url" field.
  String? _mediaUrl;
  String get mediaUrl => _mediaUrl ?? '';
  bool hasMediaUrl() => _mediaUrl != null;

  void _initializeFields() {
    _createdAt = snapshotData['created_at'] as DateTime?;
    _name = snapshotData['name'] as String?;
    _endDate = snapshotData['end_date'] as DateTime?;
    _link = snapshotData['link'] as String?;
    _mediaUrl = snapshotData['media_url'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('adverts');

  static Stream<AdvertsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => AdvertsRecord.fromSnapshot(s));

  static Future<AdvertsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => AdvertsRecord.fromSnapshot(s));

  static AdvertsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AdvertsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AdvertsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AdvertsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AdvertsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AdvertsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAdvertsRecordData({
  DateTime? createdAt,
  String? name,
  DateTime? endDate,
  String? link,
  String? mediaUrl,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_at': createdAt,
      'name': name,
      'end_date': endDate,
      'link': link,
      'media_url': mediaUrl,
    }.withoutNulls,
  );

  return firestoreData;
}

class AdvertsRecordDocumentEquality implements Equality<AdvertsRecord> {
  const AdvertsRecordDocumentEquality();

  @override
  bool equals(AdvertsRecord? e1, AdvertsRecord? e2) {
    return e1?.createdAt == e2?.createdAt &&
        e1?.name == e2?.name &&
        e1?.endDate == e2?.endDate &&
        e1?.link == e2?.link &&
        e1?.mediaUrl == e2?.mediaUrl;
  }

  @override
  int hash(AdvertsRecord? e) => const ListEquality()
      .hash([e?.createdAt, e?.name, e?.endDate, e?.link, e?.mediaUrl]);

  @override
  bool isValidKey(Object? o) => o is AdvertsRecord;
}
