import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class Tags1Record extends FirestoreRecord {
  Tags1Record._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "side" field.
  String? _side;
  String get side => _side ?? '';
  bool hasSide() => _side != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _side = snapshotData['side'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('tags_1');

  static Stream<Tags1Record> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Tags1Record.fromSnapshot(s));

  static Future<Tags1Record> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Tags1Record.fromSnapshot(s));

  static Tags1Record fromSnapshot(DocumentSnapshot snapshot) => Tags1Record._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Tags1Record getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Tags1Record._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Tags1Record(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Tags1Record &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTags1RecordData({
  String? name,
  String? side,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'side': side,
    }.withoutNulls,
  );

  return firestoreData;
}

class Tags1RecordDocumentEquality implements Equality<Tags1Record> {
  const Tags1RecordDocumentEquality();

  @override
  bool equals(Tags1Record? e1, Tags1Record? e2) {
    return e1?.name == e2?.name && e1?.side == e2?.side;
  }

  @override
  int hash(Tags1Record? e) => const ListEquality().hash([e?.name, e?.side]);

  @override
  bool isValidKey(Object? o) => o is Tags1Record;
}
