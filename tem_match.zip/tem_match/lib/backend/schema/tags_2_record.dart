import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class Tags2Record extends FirestoreRecord {
  Tags2Record._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "side" field.
  String? _side;
  String get side => _side ?? '';
  bool hasSide() => _side != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _side = snapshotData['side'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('tags_2');

  static Stream<Tags2Record> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Tags2Record.fromSnapshot(s));

  static Future<Tags2Record> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Tags2Record.fromSnapshot(s));

  static Tags2Record fromSnapshot(DocumentSnapshot snapshot) => Tags2Record._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Tags2Record getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Tags2Record._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Tags2Record(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Tags2Record &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTags2RecordData({
  String? name,
  String? side,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'side': side,
    }.withoutNulls,
  );

  return firestoreData;
}

class Tags2RecordDocumentEquality implements Equality<Tags2Record> {
  const Tags2RecordDocumentEquality();

  @override
  bool equals(Tags2Record? e1, Tags2Record? e2) {
    return e1?.name == e2?.name && e1?.side == e2?.side;
  }

  @override
  int hash(Tags2Record? e) => const ListEquality().hash([e?.name, e?.side]);

  @override
  bool isValidKey(Object? o) => o is Tags2Record;
}
