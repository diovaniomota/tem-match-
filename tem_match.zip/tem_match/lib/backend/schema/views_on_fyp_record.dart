import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class ViewsOnFypRecord extends FirestoreRecord {
  ViewsOnFypRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "review_at" field.
  DateTime? _reviewAt;
  DateTime? get reviewAt => _reviewAt;
  bool hasReviewAt() => _reviewAt != null;

  // "user_a" field.
  DocumentReference? _userA;
  DocumentReference? get userA => _userA;
  bool hasUserA() => _userA != null;

  // "user_b" field.
  DocumentReference? _userB;
  DocumentReference? get userB => _userB;
  bool hasUserB() => _userB != null;

  void _initializeFields() {
    _createdAt = snapshotData['created_at'] as DateTime?;
    _reviewAt = snapshotData['review_at'] as DateTime?;
    _userA = snapshotData['user_a'] as DocumentReference?;
    _userB = snapshotData['user_b'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('views_on_fyp');

  static Stream<ViewsOnFypRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ViewsOnFypRecord.fromSnapshot(s));

  static Future<ViewsOnFypRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ViewsOnFypRecord.fromSnapshot(s));

  static ViewsOnFypRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ViewsOnFypRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ViewsOnFypRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ViewsOnFypRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ViewsOnFypRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ViewsOnFypRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createViewsOnFypRecordData({
  DateTime? createdAt,
  DateTime? reviewAt,
  DocumentReference? userA,
  DocumentReference? userB,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_at': createdAt,
      'review_at': reviewAt,
      'user_a': userA,
      'user_b': userB,
    }.withoutNulls,
  );

  return firestoreData;
}

class ViewsOnFypRecordDocumentEquality implements Equality<ViewsOnFypRecord> {
  const ViewsOnFypRecordDocumentEquality();

  @override
  bool equals(ViewsOnFypRecord? e1, ViewsOnFypRecord? e2) {
    return e1?.createdAt == e2?.createdAt &&
        e1?.reviewAt == e2?.reviewAt &&
        e1?.userA == e2?.userA &&
        e1?.userB == e2?.userB;
  }

  @override
  int hash(ViewsOnFypRecord? e) => const ListEquality()
      .hash([e?.createdAt, e?.reviewAt, e?.userA, e?.userB]);

  @override
  bool isValidKey(Object? o) => o is ViewsOnFypRecord;
}
