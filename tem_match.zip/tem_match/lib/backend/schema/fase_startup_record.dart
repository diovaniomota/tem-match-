import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class FaseStartupRecord extends FirestoreRecord {
  FaseStartupRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('fase_startup');

  static Stream<FaseStartupRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FaseStartupRecord.fromSnapshot(s));

  static Future<FaseStartupRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FaseStartupRecord.fromSnapshot(s));

  static FaseStartupRecord fromSnapshot(DocumentSnapshot snapshot) =>
      FaseStartupRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FaseStartupRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FaseStartupRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FaseStartupRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FaseStartupRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFaseStartupRecordData({
  String? name,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
    }.withoutNulls,
  );

  return firestoreData;
}

class FaseStartupRecordDocumentEquality implements Equality<FaseStartupRecord> {
  const FaseStartupRecordDocumentEquality();

  @override
  bool equals(FaseStartupRecord? e1, FaseStartupRecord? e2) {
    return e1?.name == e2?.name;
  }

  @override
  int hash(FaseStartupRecord? e) => const ListEquality().hash([e?.name]);

  @override
  bool isValidKey(Object? o) => o is FaseStartupRecord;
}
