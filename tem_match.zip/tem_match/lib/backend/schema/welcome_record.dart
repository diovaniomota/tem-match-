import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class WelcomeRecord extends FirestoreRecord {
  WelcomeRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "subtitle" field.
  String? _subtitle;
  String get subtitle => _subtitle ?? '';
  bool hasSubtitle() => _subtitle != null;

  // "order" field.
  int? _order;
  int get order => _order ?? 0;
  bool hasOrder() => _order != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _subtitle = snapshotData['subtitle'] as String?;
    _order = castToType<int>(snapshotData['order']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('welcome');

  static Stream<WelcomeRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => WelcomeRecord.fromSnapshot(s));

  static Future<WelcomeRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => WelcomeRecord.fromSnapshot(s));

  static WelcomeRecord fromSnapshot(DocumentSnapshot snapshot) =>
      WelcomeRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static WelcomeRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      WelcomeRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'WelcomeRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is WelcomeRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createWelcomeRecordData({
  String? title,
  String? subtitle,
  int? order,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'subtitle': subtitle,
      'order': order,
    }.withoutNulls,
  );

  return firestoreData;
}

class WelcomeRecordDocumentEquality implements Equality<WelcomeRecord> {
  const WelcomeRecordDocumentEquality();

  @override
  bool equals(WelcomeRecord? e1, WelcomeRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.subtitle == e2?.subtitle &&
        e1?.order == e2?.order;
  }

  @override
  int hash(WelcomeRecord? e) =>
      const ListEquality().hash([e?.title, e?.subtitle, e?.order]);

  @override
  bool isValidKey(Object? o) => o is WelcomeRecord;
}
