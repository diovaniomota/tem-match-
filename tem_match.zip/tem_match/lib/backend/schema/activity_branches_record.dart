import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class ActivityBranchesRecord extends FirestoreRecord {
  ActivityBranchesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('activity_branches');

  static Stream<ActivityBranchesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ActivityBranchesRecord.fromSnapshot(s));

  static Future<ActivityBranchesRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => ActivityBranchesRecord.fromSnapshot(s));

  static ActivityBranchesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ActivityBranchesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ActivityBranchesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ActivityBranchesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ActivityBranchesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ActivityBranchesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createActivityBranchesRecordData({
  String? name,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
    }.withoutNulls,
  );

  return firestoreData;
}

class ActivityBranchesRecordDocumentEquality
    implements Equality<ActivityBranchesRecord> {
  const ActivityBranchesRecordDocumentEquality();

  @override
  bool equals(ActivityBranchesRecord? e1, ActivityBranchesRecord? e2) {
    return e1?.name == e2?.name;
  }

  @override
  int hash(ActivityBranchesRecord? e) => const ListEquality().hash([e?.name]);

  @override
  bool isValidKey(Object? o) => o is ActivityBranchesRecord;
}
