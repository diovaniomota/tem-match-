import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "already_read_terms" field.
  bool? _alreadyReadTerms;
  bool get alreadyReadTerms => _alreadyReadTerms ?? false;
  bool hasAlreadyReadTerms() => _alreadyReadTerms != null;

  // "email_notifications" field.
  bool? _emailNotifications;
  bool get emailNotifications => _emailNotifications ?? false;
  bool hasEmailNotifications() => _emailNotifications != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  bool hasWebsite() => _website != null;

  // "biography" field.
  String? _biography;
  String get biography => _biography ?? '';
  bool hasBiography() => _biography != null;

  // "document" field.
  String? _document;
  String get document => _document ?? '';
  bool hasDocument() => _document != null;

  // "side" field.
  String? _side;
  String get side => _side ?? '';
  bool hasSide() => _side != null;

  // "activity_branch" field.
  DocumentReference? _activityBranch;
  DocumentReference? get activityBranch => _activityBranch;
  bool hasActivityBranch() => _activityBranch != null;

  // "address" field.
  DocumentReference? _address;
  DocumentReference? get address => _address;
  bool hasAddress() => _address != null;

  // "admin" field.
  bool? _admin;
  bool get admin => _admin ?? false;
  bool hasAdmin() => _admin != null;

  // "fase_startup" field.
  DocumentReference? _faseStartup;
  DocumentReference? get faseStartup => _faseStartup;
  bool hasFaseStartup() => _faseStartup != null;

  // "valuation_startup" field.
  DocumentReference? _valuationStartup;
  DocumentReference? get valuationStartup => _valuationStartup;
  bool hasValuationStartup() => _valuationStartup != null;

  // "question_1" field.
  DocumentReference? _question1;
  DocumentReference? get question1 => _question1;
  bool hasQuestion1() => _question1 != null;

  // "question_2" field.
  DocumentReference? _question2;
  DocumentReference? get question2 => _question2;
  bool hasQuestion2() => _question2 != null;

  // "question_3" field.
  DocumentReference? _question3;
  DocumentReference? get question3 => _question3;
  bool hasQuestion3() => _question3 != null;

  // "tags_1" field.
  List<String>? _tags1;
  List<String> get tags1 => _tags1 ?? const [];
  bool hasTags1() => _tags1 != null;

  // "tags_2" field.
  List<String>? _tags2;
  List<String> get tags2 => _tags2 ?? const [];
  bool hasTags2() => _tags2 != null;

  // "is_banned" field.
  bool? _isBanned;
  bool get isBanned => _isBanned ?? false;
  bool hasIsBanned() => _isBanned != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _alreadyReadTerms = snapshotData['already_read_terms'] as bool?;
    _emailNotifications = snapshotData['email_notifications'] as bool?;
    _website = snapshotData['website'] as String?;
    _biography = snapshotData['biography'] as String?;
    _document = snapshotData['document'] as String?;
    _side = snapshotData['side'] as String?;
    _activityBranch = snapshotData['activity_branch'] as DocumentReference?;
    _address = snapshotData['address'] as DocumentReference?;
    _admin = snapshotData['admin'] as bool?;
    _faseStartup = snapshotData['fase_startup'] as DocumentReference?;
    _valuationStartup = snapshotData['valuation_startup'] as DocumentReference?;
    _question1 = snapshotData['question_1'] as DocumentReference?;
    _question2 = snapshotData['question_2'] as DocumentReference?;
    _question3 = snapshotData['question_3'] as DocumentReference?;
    _tags1 = getDataList(snapshotData['tags_1']);
    _tags2 = getDataList(snapshotData['tags_2']);
    _isBanned = snapshotData['is_banned'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  bool? alreadyReadTerms,
  bool? emailNotifications,
  String? website,
  String? biography,
  String? document,
  String? side,
  DocumentReference? activityBranch,
  DocumentReference? address,
  bool? admin,
  DocumentReference? faseStartup,
  DocumentReference? valuationStartup,
  DocumentReference? question1,
  DocumentReference? question2,
  DocumentReference? question3,
  bool? isBanned,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'already_read_terms': alreadyReadTerms,
      'email_notifications': emailNotifications,
      'website': website,
      'biography': biography,
      'document': document,
      'side': side,
      'activity_branch': activityBranch,
      'address': address,
      'admin': admin,
      'fase_startup': faseStartup,
      'valuation_startup': valuationStartup,
      'question_1': question1,
      'question_2': question2,
      'question_3': question3,
      'is_banned': isBanned,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.alreadyReadTerms == e2?.alreadyReadTerms &&
        e1?.emailNotifications == e2?.emailNotifications &&
        e1?.website == e2?.website &&
        e1?.biography == e2?.biography &&
        e1?.document == e2?.document &&
        e1?.side == e2?.side &&
        e1?.activityBranch == e2?.activityBranch &&
        e1?.address == e2?.address &&
        e1?.admin == e2?.admin &&
        e1?.faseStartup == e2?.faseStartup &&
        e1?.valuationStartup == e2?.valuationStartup &&
        e1?.question1 == e2?.question1 &&
        e1?.question2 == e2?.question2 &&
        e1?.question3 == e2?.question3 &&
        listEquality.equals(e1?.tags1, e2?.tags1) &&
        listEquality.equals(e1?.tags2, e2?.tags2) &&
        e1?.isBanned == e2?.isBanned;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.alreadyReadTerms,
        e?.emailNotifications,
        e?.website,
        e?.biography,
        e?.document,
        e?.side,
        e?.activityBranch,
        e?.address,
        e?.admin,
        e?.faseStartup,
        e?.valuationStartup,
        e?.question1,
        e?.question2,
        e?.question3,
        e?.tags1,
        e?.tags2,
        e?.isBanned
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
