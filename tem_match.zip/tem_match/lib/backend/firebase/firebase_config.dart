import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBHvZ1udzXfY83uELpSXg7Y2_QZd7jwxio",
            authDomain: "tem-match.firebaseapp.com",
            projectId: "tem-match",
            storageBucket: "tem-match.appspot.com",
            messagingSenderId: "712765184635",
            appId: "1:712765184635:web:05c45c2aff739d7abce0de",
            measurementId: "G-39J3929NPL"));
  } else {
    await Firebase.initializeApp();
  }
}
