import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/home/advert/advert_widget.dart';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:flutter/material.dart';

Future<bool> adverts(
  BuildContext context, {
  bool? showAnyway,
}) async {
  List<AdvertsRecord>? fetchAdverts;
  bool? watched;

  logFirebaseEvent('Adverts_update_app_state');
  FFAppState().ad = FFAppState().ad + 1;
  if ((FFAppState().ad >= getRemoteConfigInt('show_ad_every')) ||
      valueOrDefault<bool>(
        showAnyway,
        false,
      )) {
    logFirebaseEvent('Adverts_update_app_state');
    FFAppState().ad = 0;
    logFirebaseEvent('Adverts_firestore_query');
    fetchAdverts = await queryAdvertsRecordOnce(
      queryBuilder: (advertsRecord) => advertsRecord.where(
        'end_date',
        isGreaterThan: getCurrentTimestamp,
      ),
    );
    if (fetchAdverts.isNotEmpty) {
      logFirebaseEvent('Adverts_alert_dialog');
      await showDialog(
        barrierDismissible: false,
        context: context,
        builder: (dialogContext) {
          return Dialog(
            elevation: 0,
            insetPadding: EdgeInsets.zero,
            backgroundColor: Colors.transparent,
            alignment: const AlignmentDirectional(0.0, 0.0)
                .resolve(Directionality.of(context)),
            child: AdvertWidget(
              advert: fetchAdverts![valueOrDefault<int>(
                random_data.randomInteger(
                    0,
                    valueOrDefault<int>(
                      valueOrDefault<int>(
                            fetchAdverts.length,
                            0,
                          ) -
                          1,
                      0,
                    )),
                0,
              )],
            ),
          );
        },
      ).then((value) => watched = value);

      return valueOrDefault<bool>(
        watched,
        false,
      );
    }
  } else {
    return true;
  }

  return false;
}
