import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/profile/components/questions/questions_widget.dart';
import 'edit_profile_page_widget.dart' show EditProfilePageWidget;
import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class EditProfilePageModel extends FlutterFlowModel<EditProfilePageWidget> {
  ///  Local state fields for this page.

  bool isStartup = false;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for name widget.
  FocusNode? nameFocusNode;
  TextEditingController? nameController;
  String? Function(BuildContext, String?)? nameControllerValidator;
  String? _nameControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 2) {
      return 'Requires at least 2 characters.';
    }
    if (val.length > 50) {
      return 'Maximum 50 characters allowed, currently ${val.length}.';
    }

    return null;
  }

  // State field(s) for website widget.
  FocusNode? websiteFocusNode;
  TextEditingController? websiteController;
  String? Function(BuildContext, String?)? websiteControllerValidator;
  // State field(s) for biography widget.
  FocusNode? biographyFocusNode;
  TextEditingController? biographyController;
  String? Function(BuildContext, String?)? biographyControllerValidator;
  String? _biographyControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.length < 2) {
      return 'Requires at least 2 characters.';
    }
    if (val.length > 200) {
      return 'Maximum 200 characters allowed, currently ${val.length}.';
    }

    return null;
  }

  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for cnpj widget.
  FocusNode? cnpjFocusNode;
  TextEditingController? cnpjController;
  final cnpjMask = MaskTextInputFormatter(mask: '##.###.###/####-##');
  String? Function(BuildContext, String?)? cnpjControllerValidator;
  // State field(s) for cpf widget.
  FocusNode? cpfFocusNode;
  TextEditingController? cpfController;
  final cpfMask = MaskTextInputFormatter(mask: '###.###.###-##');
  String? Function(BuildContext, String?)? cpfControllerValidator;
  // Model for Questions component.
  late QuestionsModel questionsModel;
  // State field(s) for PlacePicker widget.
  var placePickerValue = const FFPlace();
  // Stores action output result for [Action Block - UpdateUser] action in Button widget.
  bool? isOK;

  @override
  void initState(BuildContext context) {
    nameControllerValidator = _nameControllerValidator;
    biographyControllerValidator = _biographyControllerValidator;
    questionsModel = createModel(context, () => QuestionsModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    nameFocusNode?.dispose();
    nameController?.dispose();

    websiteFocusNode?.dispose();
    websiteController?.dispose();

    biographyFocusNode?.dispose();
    biographyController?.dispose();

    tabBarController?.dispose();
    cnpjFocusNode?.dispose();
    cnpjController?.dispose();

    cpfFocusNode?.dispose();
    cpfController?.dispose();

    questionsModel.dispose();
  }

  /// Action blocks.
  Future<bool?> updateUser(
    BuildContext context, {
    required bool? isFirst,
  }) async {
    AddressesRecord? newAddress;

    final firestoreBatch = FirebaseFirestore.instance.batch();
    try {
      if (uploadedFileUrl != '') {
        logFirebaseEvent('UpdateUser_backend_call');

        firestoreBatch.update(
            currentUserReference!,
            createUsersRecordData(
              photoUrl: uploadedFileUrl,
            ));
      } else {
        if (isFirst!) {
          if (currentUserPhoto == '') {
            logFirebaseEvent('UpdateUser_show_snack_bar');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Insira uma imagem para continuar.',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Readex Pro',
                        color: FlutterFlowTheme.of(context).primaryText,
                        letterSpacing: 0.0,
                      ),
                ),
                duration: const Duration(milliseconds: 2000),
                backgroundColor: FlutterFlowTheme.of(context).alternate,
              ),
            );
            return null;
          }
        }
      }

      if ((cnpjController.text == '') &&
          (cpfController.text == '')) {
        logFirebaseEvent('UpdateUser_show_snack_bar');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Insira um documento para continuar.',
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Readex Pro',
                    color: FlutterFlowTheme.of(context).primaryText,
                    letterSpacing: 0.0,
                  ),
            ),
            duration: const Duration(milliseconds: 2000),
            backgroundColor: FlutterFlowTheme.of(context).alternate,
          ),
        );
        return null;
      } else {
        if (tabBarCurrentIndex == 0) {
          if (!((String doc) {
            return doc.replaceAll(RegExp(r'[^\d]'), '').length == 14
                ? true
                : false;
          }(cnpjController.text))) {
            logFirebaseEvent('UpdateUser_show_snack_bar');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'CNPJ inválido.',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Readex Pro',
                        color: FlutterFlowTheme.of(context).primaryText,
                        letterSpacing: 0.0,
                      ),
                ),
                duration: const Duration(milliseconds: 2000),
                backgroundColor: FlutterFlowTheme.of(context).alternate,
              ),
            );
            return null;
          } else {
            logFirebaseEvent('UpdateUser_backend_call');

            firestoreBatch.update(
                currentUserReference!,
                createUsersRecordData(
                  document: cnpjController.text,
                ));
          }
        } else {
          if (!((String doc) {
            return doc.replaceAll(RegExp(r'[^\d]'), '').length == 11
                ? true
                : false;
          }(cpfController.text))) {
            logFirebaseEvent('UpdateUser_show_snack_bar');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'CPF inválido.',
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Readex Pro',
                        color: FlutterFlowTheme.of(context).primaryText,
                        letterSpacing: 0.0,
                      ),
                ),
                duration: const Duration(milliseconds: 2000),
                backgroundColor: FlutterFlowTheme.of(context).alternate,
              ),
            );
            return null;
          } else {
            logFirebaseEvent('UpdateUser_backend_call');

            firestoreBatch.update(
                currentUserReference!,
                createUsersRecordData(
                  document: cpfController.text,
                ));
          }
        }
      }

      if (isStartup) {
        if ((questionsModel.activityBranchValue == null ||
                questionsModel.activityBranchValue == '') &&
            (questionsModel.faseStartupValue == null ||
                questionsModel.faseStartupValue == '') &&
            (questionsModel.valuationStartupValue == null ||
                questionsModel.valuationStartupValue == '') &&
            (questionsModel.question1Value == null ||
                questionsModel.question1Value == '') &&
            (questionsModel.question2Value == null ||
                questionsModel.question2Value == '') &&
            (questionsModel.question3Value == null ||
                questionsModel.question3Value == '')) {
          logFirebaseEvent('UpdateUser_show_snack_bar');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Responda às perguntas.',
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      color: FlutterFlowTheme.of(context).primaryText,
                      letterSpacing: 0.0,
                    ),
              ),
              duration: const Duration(milliseconds: 2000),
              backgroundColor: FlutterFlowTheme.of(context).alternate,
            ),
          );
          return null;
        } else {
          logFirebaseEvent('UpdateUser_backend_call');

          firestoreBatch.update(
              currentUserReference!,
              createUsersRecordData(
                faseStartup: questionsModel.faseStartup,
                valuationStartup: questionsModel.valuationStartup,
                question1: questionsModel.question1,
                question2: questionsModel.question2,
                question3: questionsModel.question3,
                activityBranch: questionsModel.activityBranch,
              ));
        }
      }
      logFirebaseEvent('UpdateUser_backend_call');

      firestoreBatch.update(
          currentUserReference!,
          createUsersRecordData(
            displayName: nameController.text,
            website: websiteController.text,
            biography: biographyController.text,
          ));
      if (placePickerValue.name != '') {
        if (currentUserDocument?.address?.id != null &&
            currentUserDocument?.address?.id != '') {
          logFirebaseEvent('UpdateUser_backend_call');

          firestoreBatch.update(
              currentUserDocument!.address!,
              createAddressesRecordData(
                address: updateAddressStruct(
                  AddressStruct(
                    local: placePickerValue.latLng,
                    name: placePickerValue.name,
                    address: placePickerValue.address,
                    city: placePickerValue.city,
                    state: placePickerValue.state,
                    country: placePickerValue.country,
                    zipCode: placePickerValue.zipCode,
                  ),
                  clearUnsetFields: false,
                ),
                modifiedAt: getCurrentTimestamp,
              ));
        } else {
          logFirebaseEvent('UpdateUser_backend_call');

          var addressesRecordReference = AddressesRecord.collection.doc();
          firestoreBatch.set(
              addressesRecordReference,
              createAddressesRecordData(
                address: updateAddressStruct(
                  AddressStruct(
                    local: placePickerValue.latLng,
                    name: placePickerValue.name,
                    address: placePickerValue.address,
                    city: placePickerValue.city,
                    state: placePickerValue.state,
                    country: placePickerValue.country,
                    zipCode: placePickerValue.zipCode,
                  ),
                  clearUnsetFields: false,
                  create: true,
                ),
                createdAt: getCurrentTimestamp,
                modifiedAt: getCurrentTimestamp,
                owner: currentUserReference,
              ));
          newAddress = AddressesRecord.getDocumentFromData(
              createAddressesRecordData(
                address: updateAddressStruct(
                  AddressStruct(
                    local: placePickerValue.latLng,
                    name: placePickerValue.name,
                    address: placePickerValue.address,
                    city: placePickerValue.city,
                    state: placePickerValue.state,
                    country: placePickerValue.country,
                    zipCode: placePickerValue.zipCode,
                  ),
                  clearUnsetFields: false,
                  create: true,
                ),
                createdAt: getCurrentTimestamp,
                modifiedAt: getCurrentTimestamp,
                owner: currentUserReference,
              ),
              addressesRecordReference);
          logFirebaseEvent('UpdateUser_backend_call');

          firestoreBatch.update(
              currentUserReference!,
              createUsersRecordData(
                address: newAddress.reference,
              ));
        }
      } else {
        if (isFirst!) {
          logFirebaseEvent('UpdateUser_show_snack_bar');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Selecione uma localização.',
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      color: FlutterFlowTheme.of(context).primaryText,
                      letterSpacing: 0.0,
                    ),
              ),
              duration: const Duration(milliseconds: 2000),
              backgroundColor: FlutterFlowTheme.of(context).alternate,
            ),
          );
          return null;
        }
      }

      if (isFirst!) {
        if (isStartup) {
          logFirebaseEvent('UpdateUser_backend_call');

          firestoreBatch.update(
              currentUserReference!,
              createUsersRecordData(
                side: 'startup',
              ));
        }
      }
      return true;
    } finally {
      await firestoreBatch.commit();
    }
  }
}
