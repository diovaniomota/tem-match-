import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'questions_widget.dart' show QuestionsWidget;
import 'package:flutter/material.dart';

class QuestionsModel extends FlutterFlowModel<QuestionsWidget> {
  ///  Local state fields for this component.

  DocumentReference? activityBranch;

  DocumentReference? faseStartup;

  DocumentReference? valuationStartup;

  DocumentReference? question1;

  DocumentReference? question2;

  DocumentReference? question3;

  ///  State fields for stateful widgets in this component.

  // State field(s) for activityBranch widget.
  String? activityBranchValue;
  FormFieldController<String>? activityBranchValueController;
  // State field(s) for faseStartup widget.
  String? faseStartupValue;
  FormFieldController<String>? faseStartupValueController;
  // State field(s) for valuationStartup widget.
  String? valuationStartupValue;
  FormFieldController<String>? valuationStartupValueController;
  // State field(s) for question1 widget.
  String? question1Value;
  FormFieldController<String>? question1ValueController;
  // State field(s) for question2 widget.
  String? question2Value;
  FormFieldController<String>? question2ValueController;
  // State field(s) for question3 widget.
  String? question3Value;
  FormFieldController<String>? question3ValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
