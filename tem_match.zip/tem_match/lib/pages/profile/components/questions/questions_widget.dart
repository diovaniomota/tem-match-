import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'questions_model.dart';
export 'questions_model.dart';

class QuestionsWidget extends StatefulWidget {
  const QuestionsWidget({super.key});

  @override
  State<QuestionsWidget> createState() => _QuestionsWidgetState();
}

class _QuestionsWidgetState extends State<QuestionsWidget> {
  late QuestionsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => QuestionsModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Modelo de Negócio',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Readex Pro',
                letterSpacing: 0.0,
              ),
        ),
        AuthUserStreamWidget(
          builder: (context) => FutureBuilder<List<ActivityBranchesRecord>>(
            future: queryActivityBranchesRecordOnce(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: SpinKitFadingFour(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 32.0,
                    ),
                  ),
                );
              }
              List<ActivityBranchesRecord>
                  activityBranchActivityBranchesRecordList = snapshot.data!;
              return FlutterFlowDropDown<String>(
                controller: _model.activityBranchValueController ??=
                    FormFieldController<String>(
                  _model.activityBranchValue ??=
                      currentUserDocument?.activityBranch?.id,
                ),
                options: List<String>.from(
                    activityBranchActivityBranchesRecordList
                        .map((e) => e.reference.id)
                        .toList()),
                optionLabels: activityBranchActivityBranchesRecordList
                    .map((e) => e.name)
                    .toList(),
                onChanged: (val) async {
                  setState(() => _model.activityBranchValue = val);
                  logFirebaseEvent('QUESTIONS_activityBranch_ON_FORM_WIDGET_');
                  logFirebaseEvent('activityBranch_update_component_state');
                  _model.activityBranch =
                      activityBranchActivityBranchesRecordList
                          .where((e) =>
                              e.reference.id == _model.activityBranchValue)
                          .toList()
                          .first
                          .reference;
                },
                width: double.infinity,
                searchHintTextStyle:
                    FlutterFlowTheme.of(context).labelMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                searchTextStyle:
                    FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      letterSpacing: 0.0,
                    ),
                hintText: 'Selecione...',
                searchHintText: 'Buscar',
                searchCursorColor: FlutterFlowTheme.of(context).alternate,
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                elevation: 2.0,
                borderColor: FlutterFlowTheme.of(context).alternate,
                borderWidth: 2.0,
                borderRadius: 8.0,
                margin: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                hidesUnderline: true,
                isSearchable: true,
                isMultiSelect: false,
              );
            },
          ),
        ),
        Text(
          'Fase da Startup',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Readex Pro',
                letterSpacing: 0.0,
              ),
        ),
        AuthUserStreamWidget(
          builder: (context) => FutureBuilder<List<FaseStartupRecord>>(
            future: queryFaseStartupRecordOnce(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: SpinKitFadingFour(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 32.0,
                    ),
                  ),
                );
              }
              List<FaseStartupRecord> faseStartupFaseStartupRecordList =
                  snapshot.data!;
              return FlutterFlowDropDown<String>(
                controller: _model.faseStartupValueController ??=
                    FormFieldController<String>(
                  _model.faseStartupValue ??=
                      currentUserDocument?.faseStartup?.id,
                ),
                options: List<String>.from(faseStartupFaseStartupRecordList
                    .map((e) => e.reference.id)
                    .toList()),
                optionLabels: faseStartupFaseStartupRecordList
                    .map((e) => e.name)
                    .toList(),
                onChanged: (val) async {
                  setState(() => _model.faseStartupValue = val);
                  logFirebaseEvent('QUESTIONS_faseStartup_ON_FORM_WIDGET_SEL');
                  logFirebaseEvent('faseStartup_update_component_state');
                  _model.faseStartup = faseStartupFaseStartupRecordList
                      .where((e) => e.reference.id == _model.faseStartupValue)
                      .toList()
                      .first
                      .reference;
                },
                width: double.infinity,
                searchHintTextStyle:
                    FlutterFlowTheme.of(context).labelMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                searchTextStyle:
                    FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      letterSpacing: 0.0,
                    ),
                hintText: 'Selecione...',
                searchHintText: 'Buscar',
                searchCursorColor: FlutterFlowTheme.of(context).alternate,
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                elevation: 2.0,
                borderColor: FlutterFlowTheme.of(context).alternate,
                borderWidth: 2.0,
                borderRadius: 8.0,
                margin: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                hidesUnderline: true,
                isSearchable: true,
                isMultiSelect: false,
              );
            },
          ),
        ),
        Text(
          'Valuation da Startup',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Readex Pro',
                letterSpacing: 0.0,
              ),
        ),
        AuthUserStreamWidget(
          builder: (context) => FutureBuilder<List<ValuationStartupRecord>>(
            future: queryValuationStartupRecordOnce(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: SpinKitFadingFour(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 32.0,
                    ),
                  ),
                );
              }
              List<ValuationStartupRecord>
                  valuationStartupValuationStartupRecordList = snapshot.data!;
              return FlutterFlowDropDown<String>(
                controller: _model.valuationStartupValueController ??=
                    FormFieldController<String>(
                  _model.valuationStartupValue ??=
                      currentUserDocument?.valuationStartup?.id,
                ),
                options: List<String>.from(
                    valuationStartupValuationStartupRecordList
                        .map((e) => e.reference.id)
                        .toList()),
                optionLabels: valuationStartupValuationStartupRecordList
                    .map((e) => e.name)
                    .toList(),
                onChanged: (val) async {
                  setState(() => _model.valuationStartupValue = val);
                  logFirebaseEvent('QUESTIONS_valuationStartup_ON_FORM_WIDGE');
                  logFirebaseEvent('valuationStartup_update_component_state');
                  _model.valuationStartup =
                      valuationStartupValuationStartupRecordList
                          .where((e) =>
                              e.reference.id == _model.valuationStartupValue)
                          .toList()
                          .first
                          .reference;
                },
                width: double.infinity,
                searchHintTextStyle:
                    FlutterFlowTheme.of(context).labelMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                searchTextStyle:
                    FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      letterSpacing: 0.0,
                    ),
                hintText: 'Selecione...',
                searchHintText: 'Buscar',
                searchCursorColor: FlutterFlowTheme.of(context).alternate,
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                elevation: 2.0,
                borderColor: FlutterFlowTheme.of(context).alternate,
                borderWidth: 2.0,
                borderRadius: 8.0,
                margin: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                hidesUnderline: true,
                isSearchable: true,
                isMultiSelect: false,
              );
            },
          ),
        ),
        Text(
          'Tem mentores?',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Readex Pro',
                letterSpacing: 0.0,
              ),
        ),
        AuthUserStreamWidget(
          builder: (context) => FutureBuilder<List<Question1Record>>(
            future: queryQuestion1RecordOnce(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: SpinKitFadingFour(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 32.0,
                    ),
                  ),
                );
              }
              List<Question1Record> question1Question1RecordList =
                  snapshot.data!;
              return FlutterFlowDropDown<String>(
                controller: _model.question1ValueController ??=
                    FormFieldController<String>(
                  _model.question1Value ??= currentUserDocument?.question1?.id,
                ),
                options: List<String>.from(question1Question1RecordList
                    .map((e) => e.reference.id)
                    .toList()),
                optionLabels:
                    question1Question1RecordList.map((e) => e.name).toList(),
                onChanged: (val) async {
                  setState(() => _model.question1Value = val);
                  logFirebaseEvent('QUESTIONS_question1_ON_FORM_WIDGET_SELEC');
                  logFirebaseEvent('question1_update_component_state');
                  _model.question1 = question1Question1RecordList
                      .where((e) => e.reference.id == _model.question1Value)
                      .toList()
                      .first
                      .reference;
                },
                width: double.infinity,
                searchHintTextStyle:
                    FlutterFlowTheme.of(context).labelMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                searchTextStyle:
                    FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      letterSpacing: 0.0,
                    ),
                hintText: 'Selecione...',
                searchHintText: 'Buscar',
                searchCursorColor: FlutterFlowTheme.of(context).alternate,
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                elevation: 2.0,
                borderColor: FlutterFlowTheme.of(context).alternate,
                borderWidth: 2.0,
                borderRadius: 8.0,
                margin: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                hidesUnderline: true,
                isSearchable: true,
                isMultiSelect: false,
              );
            },
          ),
        ),
        Text(
          'Tem Investidor(es) Anjo?',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Readex Pro',
                letterSpacing: 0.0,
              ),
        ),
        AuthUserStreamWidget(
          builder: (context) => FutureBuilder<List<Question2Record>>(
            future: queryQuestion2RecordOnce(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: SpinKitFadingFour(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 32.0,
                    ),
                  ),
                );
              }
              List<Question2Record> question2Question2RecordList =
                  snapshot.data!;
              return FlutterFlowDropDown<String>(
                controller: _model.question2ValueController ??=
                    FormFieldController<String>(
                  _model.question2Value ??= currentUserDocument?.question2?.id,
                ),
                options: List<String>.from(question2Question2RecordList
                    .map((e) => e.reference.id)
                    .toList()),
                optionLabels:
                    question2Question2RecordList.map((e) => e.name).toList(),
                onChanged: (val) async {
                  setState(() => _model.question2Value = val);
                  logFirebaseEvent('QUESTIONS_question2_ON_FORM_WIDGET_SELEC');
                  logFirebaseEvent('question2_update_component_state');
                  _model.question2 = question2Question2RecordList
                      .where((e) => e.reference.id == _model.question2Value)
                      .toList()
                      .first
                      .reference;
                },
                width: double.infinity,
                searchHintTextStyle:
                    FlutterFlowTheme.of(context).labelMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                searchTextStyle:
                    FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      letterSpacing: 0.0,
                    ),
                hintText: 'Selecione...',
                searchHintText: 'Buscar',
                searchCursorColor: FlutterFlowTheme.of(context).alternate,
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                elevation: 2.0,
                borderColor: FlutterFlowTheme.of(context).alternate,
                borderWidth: 2.0,
                borderRadius: 8.0,
                margin: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                hidesUnderline: true,
                isSearchable: true,
                isMultiSelect: false,
              );
            },
          ),
        ),
        Text(
          'Valuation já validado por algum VC?',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Readex Pro',
                letterSpacing: 0.0,
              ),
        ),
        AuthUserStreamWidget(
          builder: (context) => FutureBuilder<List<Question3Record>>(
            future: queryQuestion3RecordOnce(),
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: SpinKitFadingFour(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 32.0,
                    ),
                  ),
                );
              }
              List<Question3Record> question3Question3RecordList =
                  snapshot.data!;
              return FlutterFlowDropDown<String>(
                controller: _model.question3ValueController ??=
                    FormFieldController<String>(
                  _model.question3Value ??= currentUserDocument?.question3?.id,
                ),
                options: List<String>.from(question3Question3RecordList
                    .map((e) => e.reference.id)
                    .toList()),
                optionLabels:
                    question3Question3RecordList.map((e) => e.name).toList(),
                onChanged: (val) async {
                  setState(() => _model.question3Value = val);
                  logFirebaseEvent('QUESTIONS_question3_ON_FORM_WIDGET_SELEC');
                  logFirebaseEvent('question3_update_component_state');
                  _model.question3 = question3Question3RecordList
                      .where((e) => e.reference.id == _model.question3Value)
                      .toList()
                      .first
                      .reference;
                },
                width: double.infinity,
                searchHintTextStyle:
                    FlutterFlowTheme.of(context).labelMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                searchTextStyle:
                    FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      letterSpacing: 0.0,
                    ),
                hintText: 'Selecione...',
                searchHintText: 'Buscar',
                searchCursorColor: FlutterFlowTheme.of(context).alternate,
                icon: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FlutterFlowTheme.of(context).secondaryText,
                  size: 24.0,
                ),
                fillColor: FlutterFlowTheme.of(context).secondaryBackground,
                elevation: 2.0,
                borderColor: FlutterFlowTheme.of(context).alternate,
                borderWidth: 2.0,
                borderRadius: 8.0,
                margin: const EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                hidesUnderline: true,
                isSearchable: true,
                isMultiSelect: false,
              );
            },
          ),
        ),
      ].divide(const SizedBox(height: 16.0)),
    );
  }
}
