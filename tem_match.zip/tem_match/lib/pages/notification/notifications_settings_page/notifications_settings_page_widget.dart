import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';
import 'notifications_settings_page_model.dart';
export 'notifications_settings_page_model.dart';

class NotificationsSettingsPageWidget extends StatefulWidget {
  const NotificationsSettingsPageWidget({super.key});

  @override
  State<NotificationsSettingsPageWidget> createState() =>
      _NotificationsSettingsPageWidgetState();
}

class _NotificationsSettingsPageWidgetState
    extends State<NotificationsSettingsPageWidget> {
  late NotificationsSettingsPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NotificationsSettingsPageModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'NotificationsSettingsPage'});
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).appBarBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: FaIcon(
              FontAwesomeIcons.angleLeft,
              color: FlutterFlowTheme.of(context).primaryText,
              size: 30.0,
            ),
            onPressed: () async {
              logFirebaseEvent('NOTIFICATIONS_SETTINGS_angleLeft_ICN_ON_');
              logFirebaseEvent('IconButton_navigate_back');
              context.pop();
            },
          ),
          title: Text(
            'Configurações',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: FlutterFlowTheme.of(context).primaryText,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: Image.asset(
                'assets/images/Background.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding:
                        const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsetsDirectional.fromSTEB(
                                0.0, 8.0, 0.0, 8.0),
                            child: Text(
                              'Escolha abaixo quais notificações você deseja receber e atualizaremos as configurações.',
                              style: FlutterFlowTheme.of(context)
                                  .bodyLarge
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (false)
                    SwitchListTile.adaptive(
                      value: _model.switchListTileValue1 ??=
                          FFAppState().pushNotifications,
                      onChanged: (newValue) async {
                        setState(() => _model.switchListTileValue1 = newValue);
                        if (newValue) {
                          logFirebaseEvent(
                              'NOTIFICATIONS_SETTINGS_SwitchListTile_ge');
                          logFirebaseEvent('SwitchListTile_update_app_state');
                          FFAppState().pushNotifications = true;
                        } else {
                          logFirebaseEvent(
                              'NOTIFICATIONS_SETTINGS_SwitchListTile_ge');
                          logFirebaseEvent('SwitchListTile_update_app_state');
                          FFAppState().pushNotifications = false;
                        }
                      },
                      title: Text(
                        'Notificações via push',
                        style: FlutterFlowTheme.of(context).titleSmall.override(
                              fontFamily: 'Readex Pro',
                              color: FlutterFlowTheme.of(context).primaryText,
                              letterSpacing: 0.0,
                            ),
                      ),
                      subtitle: Text(
                        'Receba notificações push de nosso aplicativo regularmente.',
                        style: FlutterFlowTheme.of(context).bodySmall.override(
                              fontFamily: 'Readex Pro',
                              color: FlutterFlowTheme.of(context).secondaryText,
                              letterSpacing: 0.0,
                            ),
                      ),
                      activeColor: FlutterFlowTheme.of(context).leve,
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                      contentPadding: const EdgeInsetsDirectional.fromSTEB(
                          24.0, 12.0, 24.0, 12.0),
                    ),
                  AuthUserStreamWidget(
                    builder: (context) => SwitchListTile.adaptive(
                      value: _model.switchListTileValue2 ??=
                          valueOrDefault<bool>(
                              currentUserDocument?.emailNotifications, false),
                      onChanged: (newValue) async {
                        setState(() => _model.switchListTileValue2 = newValue);
                        if (newValue) {
                          logFirebaseEvent(
                              'NOTIFICATIONS_SETTINGS_SwitchListTile_uv');
                          logFirebaseEvent('SwitchListTile_backend_call');

                          await currentUserReference!
                              .update(createUsersRecordData(
                            emailNotifications: true,
                          ));
                        } else {
                          logFirebaseEvent(
                              'NOTIFICATIONS_SETTINGS_SwitchListTile_uv');
                          logFirebaseEvent('SwitchListTile_backend_call');

                          await currentUserReference!
                              .update(createUsersRecordData(
                            emailNotifications: false,
                          ));
                        }
                      },
                      title: Text(
                        'Notificações por e-mail',
                        style: FlutterFlowTheme.of(context).titleSmall.override(
                              fontFamily: 'Readex Pro',
                              color: FlutterFlowTheme.of(context).primaryText,
                              letterSpacing: 0.0,
                            ),
                      ),
                      subtitle: Text(
                        'Receba notificações por e-mail de nossa equipe de marketing sobre novos recursos.',
                        style: FlutterFlowTheme.of(context).bodySmall.override(
                              fontFamily: 'Readex Pro',
                              color: FlutterFlowTheme.of(context).secondaryText,
                              letterSpacing: 0.0,
                            ),
                      ),
                      activeColor: FlutterFlowTheme.of(context).leve,
                      dense: false,
                      controlAffinity: ListTileControlAffinity.trailing,
                      contentPadding: const EdgeInsetsDirectional.fromSTEB(
                          24.0, 12.0, 24.0, 12.0),
                    ),
                  ),
                ]
                    .addToStart(const SizedBox(height: 20.0))
                    .addToEnd(const SizedBox(height: 20.0)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
