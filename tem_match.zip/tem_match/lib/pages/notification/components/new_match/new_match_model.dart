import '/flutter_flow/flutter_flow_util.dart';
import 'new_match_widget.dart' show NewMatchWidget;
import 'package:flutter/material.dart';

class NewMatchModel extends FlutterFlowModel<NewMatchWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
