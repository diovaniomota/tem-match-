import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:async';
import 'notification_page_widget.dart' show NotificationPageWidget;
import 'package:flutter/material.dart';

class NotificationPageModel extends FlutterFlowModel<NotificationPageWidget> {
  ///  Local state fields for this page.

  int aux = 0;

  List<NotificationsRecord> auxList = [];
  void addToAuxList(NotificationsRecord item) => auxList.add(item);
  void removeFromAuxList(NotificationsRecord item) => auxList.remove(item);
  void removeAtIndexFromAuxList(int index) => auxList.removeAt(index);
  void insertAtIndexInAuxList(int index, NotificationsRecord item) =>
      auxList.insert(index, item);
  void updateAuxListAtIndex(
          int index, Function(NotificationsRecord) updateFn) =>
      auxList[index] = updateFn(auxList[index]);

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  Completer<List<NotificationsRecord>>? firestoreRequestCompleter;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }

  /// Action blocks.
  Future setReady(BuildContext context) async {
    List<NotificationsRecord>? fetchNotifications;

    logFirebaseEvent('SetReady_firestore_query');
    fetchNotifications = await queryNotificationsRecordOnce(
      queryBuilder: (notificationsRecord) => notificationsRecord
          .where(
            'recipient',
            isEqualTo: currentUserReference,
          )
          .where(
            'read_at',
            isEqualTo: null,
          ),
    );
    if (fetchNotifications.isNotEmpty) {
      logFirebaseEvent('SetReady_update_page_state');
      auxList = fetchNotifications
          .where((e) => !e.hasReadAt())
          .toList()
          .toList()
          .cast<NotificationsRecord>();
      while (aux < auxList.length) {
        logFirebaseEvent('SetReady_backend_call');

        await auxList[aux].reference.update(createNotificationsRecordData(
              readAt: getCurrentTimestamp,
            ));
        logFirebaseEvent('SetReady_update_page_state');
        aux = aux + 1;
      }
    } else {
      return;
    }
  }

  /// Additional helper methods.
  Future waitForFirestoreRequestCompleted({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(const Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = firestoreRequestCompleter?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}
