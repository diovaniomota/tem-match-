import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/notification/components/new_match/new_match_widget.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'notification_page_model.dart';
export 'notification_page_model.dart';

class NotificationPageWidget extends StatefulWidget {
  const NotificationPageWidget({super.key});

  @override
  State<NotificationPageWidget> createState() => _NotificationPageWidgetState();
}

class _NotificationPageWidgetState extends State<NotificationPageWidget> {
  late NotificationPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NotificationPageModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'NotificationPage'});
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('NOTIFICATION_NotificationPage_ON_INIT_ST');
      logFirebaseEvent('NotificationPage_action_block');
      await _model.setReady(context);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).appBarBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: FaIcon(
              FontAwesomeIcons.angleLeft,
              color: FlutterFlowTheme.of(context).info,
              size: 30.0,
            ),
            onPressed: () async {
              logFirebaseEvent('NOTIFICATION_angleLeft_ICN_ON_TAP');
              logFirebaseEvent('IconButton_navigate_back');
              context.pop();
            },
          ),
          title: Text(
            'Notificações',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: FlutterFlowTheme.of(context).primaryText,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [
            Align(
              alignment: const AlignmentDirectional(0.0, 0.0),
              child: Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 8.0, 0.0),
                child: FlutterFlowIconButton(
                  borderColor: Colors.transparent,
                  borderRadius: 20.0,
                  borderWidth: 1.0,
                  buttonSize: 40.0,
                  icon: Icon(
                    Icons.settings_rounded,
                    color: FlutterFlowTheme.of(context).primaryText,
                    size: 24.0,
                  ),
                  onPressed: () async {
                    logFirebaseEvent(
                        'NOTIFICATION_settings_rounded_ICN_ON_TAP');
                    logFirebaseEvent('IconButton_navigate_to');

                    context.pushNamed(
                      'NotificationsSettingsPage',
                      extra: <String, dynamic>{
                        kTransitionInfoKey: const TransitionInfo(
                          hasTransition: true,
                          transitionType: PageTransitionType.rightToLeft,
                        ),
                      },
                    );
                  },
                ),
              ),
            ),
          ],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            image: DecorationImage(
              fit: BoxFit.cover,
              image: Image.asset(
                'assets/images/Background.jpg',
              ).image,
            ),
          ),
          child: FutureBuilder<List<NotificationsRecord>>(
            future: (_model.firestoreRequestCompleter ??=
                    Completer<List<NotificationsRecord>>()
                      ..complete(queryNotificationsRecordOnce(
                        queryBuilder: (notificationsRecord) =>
                            notificationsRecord
                                .where(
                                  'recipient',
                                  isEqualTo: currentUserReference,
                                )
                                .orderBy('created_at', descending: true),
                        limit: 50,
                      )))
                .future,
            builder: (context, snapshot) {
              // Customize what your widget looks like when it's loading.
              if (!snapshot.hasData) {
                return Center(
                  child: SizedBox(
                    width: 40.0,
                    height: 40.0,
                    child: SpinKitFadingCube(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 40.0,
                    ),
                  ),
                );
              }
              List<NotificationsRecord> columnNotificationsRecordList =
                  snapshot.data!;
              if (columnNotificationsRecordList.isEmpty) {
                return Center(
                  child: SvgPicture.asset(
                    'assets/images/undraw_new_notifications_re_xpcv.svg',
                    width: MediaQuery.sizeOf(context).width * 0.5,
                  ),
                );
              }
              return RefreshIndicator(
                color: FlutterFlowTheme.of(context).primary,
                backgroundColor: FlutterFlowTheme.of(context).accent4,
                strokeWidth: 3.0,
                onRefresh: () async {
                  logFirebaseEvent('NOTIFICATION_ListView_dd1f99bt_ON_PULL_T');
                  logFirebaseEvent('Column_refresh_database_request');
                  setState(() => _model.firestoreRequestCompleter = null);
                  await _model.waitForFirestoreRequestCompleted();
                },
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children:
                        List.generate(columnNotificationsRecordList.length,
                                (columnIndex) {
                      final columnNotificationsRecord =
                          columnNotificationsRecordList[columnIndex];
                      return Builder(
                        builder: (context) {
                          if (columnNotificationsRecord.type == 'newMatch') {
                            return NewMatchWidget(
                              key: Key(
                                  'Key705_${columnIndex}_of_${columnNotificationsRecordList.length}'),
                              notification: columnNotificationsRecord,
                            );
                          } else {
                            return Container(
                              decoration: const BoxDecoration(),
                            );
                          }
                        },
                      );
                    })
                            .divide(const SizedBox(height: 16.0))
                            .around(const SizedBox(height: 16.0)),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
