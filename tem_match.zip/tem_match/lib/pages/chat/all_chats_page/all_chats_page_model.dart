import '/flutter_flow/chat/index.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'all_chats_page_widget.dart' show AllChatsPageWidget;
import 'package:flutter/material.dart';

class AllChatsPageModel extends FlutterFlowModel<AllChatsPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
