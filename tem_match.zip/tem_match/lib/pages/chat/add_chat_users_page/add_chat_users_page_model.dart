import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'add_chat_users_page_widget.dart' show AddChatUsersPageWidget;
import 'package:flutter/material.dart';

class AddChatUsersPageModel extends FlutterFlowModel<AddChatUsersPageWidget> {
  ///  Local state fields for this page.

  List<UsersRecord> users = [];
  void addToUsers(UsersRecord item) => users.add(item);
  void removeFromUsers(UsersRecord item) => users.remove(item);
  void removeAtIndexFromUsers(int index) => users.removeAt(index);
  void insertAtIndexInUsers(int index, UsersRecord item) =>
      users.insert(index, item);
  void updateUsersAtIndex(int index, Function(UsersRecord) updateFn) =>
      users[index] = updateFn(users[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }

  /// Action blocks.
  Future loadUsers(BuildContext context) async {
    List<MatchRecord>? mtS;
    List<MatchRecord>? mtR;
    List<UsersRecord>? fetchUsers;

    logFirebaseEvent('LoadUsers_firestore_query');
    mtS = await queryMatchRecordOnce(
      queryBuilder: (matchRecord) => matchRecord.where(
        'sender',
        isEqualTo: currentUserReference,
      ),
    );
    logFirebaseEvent('LoadUsers_firestore_query');
    mtR = await queryMatchRecordOnce(
      queryBuilder: (matchRecord) => matchRecord.where(
        'recipient',
        isEqualTo: currentUserReference,
      ),
    );
    logFirebaseEvent('LoadUsers_firestore_query');
    fetchUsers = await queryUsersRecordOnce(
      queryBuilder: (usersRecord) => usersRecord.whereIn(
          'uid',
          (List<String> var1) {
            return ['XX', ...var1];
          }(functions
              .getOnlyRepeatedString(
                  mtS!
                      .map((e) => e.recipient?.id)
                      .withoutNulls
                      .toList()
                      .toList(),
                  mtR!.map((e) => e.sender?.id).withoutNulls.toList().toList())
              .toList())),
    );
    logFirebaseEvent('LoadUsers_update_page_state');
    users = fetchUsers
        .where((e) => !e.isBanned)
        .toList()
        .toList()
        .cast<UsersRecord>();
  }
}
