import '/flutter_flow/flutter_flow_util.dart';
import 'no_chat_widget.dart' show NoChatWidget;
import 'package:flutter/material.dart';

class NoChatModel extends FlutterFlowModel<NoChatWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
