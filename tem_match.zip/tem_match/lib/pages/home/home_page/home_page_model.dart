import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/home/fyp/fyp_widget.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'home_page_widget.dart' show HomePageWidget;
import 'package:flutter/material.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  bool isLoaded = false;

  List<ViewsOnFypRecord> views = [];
  void addToViews(ViewsOnFypRecord item) => views.add(item);
  void removeFromViews(ViewsOnFypRecord item) => views.remove(item);
  void removeAtIndexFromViews(int index) => views.removeAt(index);
  void insertAtIndexInViews(int index, ViewsOnFypRecord item) =>
      views.insert(index, item);
  void updateViewsAtIndex(int index, Function(ViewsOnFypRecord) updateFn) =>
      views[index] = updateFn(views[index]);

  List<MatchRecord> matches = [];
  void addToMatches(MatchRecord item) => matches.add(item);
  void removeFromMatches(MatchRecord item) => matches.remove(item);
  void removeAtIndexFromMatches(int index) => matches.removeAt(index);
  void insertAtIndexInMatches(int index, MatchRecord item) =>
      matches.insert(index, item);
  void updateMatchesAtIndex(int index, Function(MatchRecord) updateFn) =>
      matches[index] = updateFn(matches[index]);

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Stores action output result for [Action Block - InitialSetting] action in HomePage widget.
  bool? ok;
  // Model for FYP component.
  late FypModel fypModel;

  @override
  void initState(BuildContext context) {
    fypModel = createModel(context, () => FypModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    fypModel.dispose();
  }

  /// Action blocks.
  Future<bool> initialSetting(BuildContext context) async {
    if (valueOrDefault<bool>(currentUserDocument?.alreadyReadTerms, false) ==
        true) {
      if (valueOrDefault(currentUserDocument?.side, '') != '') {
        return true;
      }

      logFirebaseEvent('InitialSetting_navigate_to');

      context.goNamed(
        'SetUserSidePage',
        extra: <String, dynamic>{
          kTransitionInfoKey: const TransitionInfo(
            hasTransition: true,
            transitionType: PageTransitionType.rightToLeft,
          ),
        },
      );

      return false;
    } else {
      logFirebaseEvent('InitialSetting_navigate_to');

      context.goNamed(
        'TermsEULAPage',
        queryParameters: {
          'mandatoryToAgree': serializeParam(
            true,
            ParamType.bool,
          ),
        }.withoutNulls,
        extra: <String, dynamic>{
          kTransitionInfoKey: const TransitionInfo(
            hasTransition: true,
            transitionType: PageTransitionType.rightToLeft,
          ),
        },
      );

      return false;
    }
  }

  Future loadFyp(BuildContext context) async {
    List<ViewsOnFypRecord>? fetchViews;
    List<MatchRecord>? fetchMatches;

    logFirebaseEvent('LoadFyp_firestore_query');
    fetchViews = await queryViewsOnFypRecordOnce(
      queryBuilder: (viewsOnFypRecord) => viewsOnFypRecord.where(
        'user_a',
        isEqualTo: currentUserReference,
      ),
    );
    logFirebaseEvent('LoadFyp_firestore_query');
    fetchMatches = await queryMatchRecordOnce(
      queryBuilder: (matchRecord) => matchRecord.where(
        'sender',
        isEqualTo: currentUserReference,
      ),
    );
    logFirebaseEvent('LoadFyp_update_page_state');
    isLoaded = true;
    matches = fetchMatches.toList().cast<MatchRecord>();
    views = fetchViews
        .where((e) => e.reviewAt! > functions.dateIgnore()!)
        .toList()
        .toList()
        .cast<ViewsOnFypRecord>();
  }
}
