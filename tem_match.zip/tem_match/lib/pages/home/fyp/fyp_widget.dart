import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_swipeable_stack.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/home/components/finished/finished_widget.dart';
import '/pages/home/f_y_p_card/f_y_p_card_widget.dart';
import '/pages/home/match/match_widget.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'fyp_model.dart';
export 'fyp_model.dart';

class FypWidget extends StatefulWidget {
  const FypWidget({
    super.key,
    required this.views,
    required this.matches,
    required this.sideFYP,
  });

  final List<ViewsOnFypRecord>? views;
  final List<MatchRecord>? matches;
  final String? sideFYP;

  @override
  State<FypWidget> createState() => _FypWidgetState();
}

class _FypWidgetState extends State<FypWidget> with TickerProviderStateMixin {
  late FypModel _model;

  final animationsMap = {
    'swipeableStackOnPageLoadAnimation': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 600.ms,
          begin: 0.0,
          end: 1.0,
        ),
      ],
    ),
  };

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FypModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('FYP_COMP_FYP_ON_INIT_STATE');
      logFirebaseEvent('FYP_firestore_query');
      _model.fetchUsers = await queryUsersRecordOnce(
        queryBuilder: (usersRecord) => usersRecord.where(
          'side',
          isEqualTo: widget.sideFYP,
        ),
        limit: 300,
      );
      logFirebaseEvent('FYP_update_component_state');
      _model.usersFyp = _model.fetchUsers!
          .where((e) => functions.filterUser(
              (currentUserDocument?.tags2.toList() ?? []).toList(),
              ((List<String> var1, List<String> var2, List<String> var3) {
                return [...var1, ...var2, ...var3];
              }(
                      widget.views!
                          .map((e) => e.userB?.id)
                          .withoutNulls
                          .toList()
                          .toList(),
                      widget.matches!
                          .map((e) => e.recipient?.id)
                          .withoutNulls
                          .toList()
                          .toList(),
                      _model.fetchUsers!
                          .where((e) => e.isBanned)
                          .toList()
                          .map((e) => e.reference.id)
                          .toList()
                          .toList()))
                  .toList(),
              e,
              FFAppState().acitivityBranchID,
              FFAppState().faseStartupID,
              FFAppState().valuationStartupID,
              FFAppState().question1,
              FFAppState().question2,
              FFAppState().question3))
          .toList()
          .toList()
          .cast<UsersRecord>();
      _model.aux = 0;
      logFirebaseEvent('FYP_firestore_query');
      _model.fetchAddresses = await queryAddressesRecordOnce();
      logFirebaseEvent('FYP_firestore_query');
      _model.fetchActivityBranches = await queryActivityBranchesRecordOnce();
      logFirebaseEvent('FYP_update_component_state');
      _model.addresses =
          _model.fetchAddresses!.toList().cast<AddressesRecord>();
      _model.activityBranches =
          _model.fetchActivityBranches!.toList().cast<ActivityBranchesRecord>();
      if (_model.usersFyp.isEmpty) {
        logFirebaseEvent('FYP_update_component_state');
        setState(() {
          _model.isFinished = true;
        });
      } else {
        if (FFAppState().location.name != '') {
          logFirebaseEvent('FYP_update_component_state');
          setState(() {
            _model.usersFyp = _model.usersFyp
                .where((e) =>
                    (functions
                            .getAddress(
                                _model.addresses.toList(), e.address?.id)
                            ?.address
                            .country ==
                        FFAppState().location.country) &&
                    (FFAppState().location.state != ''
                        ? (functions
                                .getAddress(
                                    _model.addresses.toList(), e.address?.id)
                                ?.address
                                .state ==
                            FFAppState().location.state)
                        : true) &&
                    (FFAppState().location.city != ''
                        ? (functions
                                .getAddress(
                                    _model.addresses.toList(), e.address?.id)
                                ?.address
                                .city ==
                            FFAppState().location.city)
                        : true))
                .toList()
                .toList()
                .cast<UsersRecord>();
          });
        }
      }

      logFirebaseEvent('FYP_update_component_state');
      setState(() {
        _model.isLoaded = true;
      });
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Builder(
      builder: (context) {
        if (!_model.isFinished) {
          return Visibility(
            visible: _model.isLoaded,
            child: Builder(
              builder: (context) => Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
                child: Builder(
                  builder: (context) {
                    final userFYP = _model.usersFyp.toList();
                    if (userFYP.isEmpty) {
                      return const FinishedWidget();
                    }
                    return FlutterFlowSwipeableStack(
                      onSwipeFn: (index) async {
                        logFirebaseEvent(
                            'FYP_SwipeableStack_zwc4m9rw_ON_WIDGET_SW');
                        final userFYPItem = userFYP[index];
                        if (userFYP[index].reference ==
                            _model.usersFyp.last.reference) {
                          logFirebaseEvent('SwipeableStack_wait__delay');
                          await Future.delayed(
                              const Duration(milliseconds: 1000));
                          logFirebaseEvent(
                              'SwipeableStack_update_component_state');
                          setState(() {
                            _model.isFinished = true;
                          });
                        }
                      },
                      onLeftSwipe: (index) async {
                        logFirebaseEvent(
                            'FYP_SwipeableStack_zwc4m9rw_ON_LEFT_SWIP');
                        final userFYPItem = userFYP[index];
                        final firestoreBatch =
                            FirebaseFirestore.instance.batch();
                        try {
                          logFirebaseEvent('SwipeableStack_firestore_query');
                          _model.fetchView = await queryViewsOnFypRecordOnce(
                            queryBuilder: (viewsOnFypRecord) => viewsOnFypRecord
                                .where(
                                  'user_a',
                                  isEqualTo: currentUserReference,
                                )
                                .where(
                                  'user_b',
                                  isEqualTo: userFYP[index].reference,
                                ),
                            singleRecord: true,
                          ).then((s) => s.firstOrNull);
                          if (_model.fetchView?.reference.id != null &&
                              _model.fetchView?.reference.id != '') {
                            logFirebaseEvent('SwipeableStack_backend_call');

                            firestoreBatch.update(
                                _model.fetchView!.reference,
                                createViewsOnFypRecordData(
                                  reviewAt: getCurrentTimestamp,
                                ));
                          } else {
                            logFirebaseEvent('SwipeableStack_backend_call');

                            firestoreBatch.set(
                                ViewsOnFypRecord.collection.doc(),
                                createViewsOnFypRecordData(
                                  createdAt: getCurrentTimestamp,
                                  reviewAt: getCurrentTimestamp,
                                  userA: currentUserReference,
                                  userB: userFYP[index].reference,
                                ));
                          }
                        } finally {
                          await firestoreBatch.commit();
                        }

                        setState(() {});
                      },
                      onRightSwipe: (index) async {
                        logFirebaseEvent(
                            'FYP_SwipeableStack_zwc4m9rw_ON_RIGHT_SWI');
                        final userFYPItem = userFYP[index];
                        final firestoreBatch =
                            FirebaseFirestore.instance.batch();
                        try {
                          logFirebaseEvent('SwipeableStack_backend_call');

                          var matchRecordReference =
                              MatchRecord.collection.doc();
                          firestoreBatch.set(
                              matchRecordReference,
                              createMatchRecordData(
                                createdAt: getCurrentTimestamp,
                                sender: currentUserReference,
                                recipient: userFYP[index].reference,
                                isSuper: _model.superMatch,
                              ));
                          _model.newMatch = MatchRecord.getDocumentFromData(
                              createMatchRecordData(
                                createdAt: getCurrentTimestamp,
                                sender: currentUserReference,
                                recipient: userFYP[index].reference,
                                isSuper: _model.superMatch,
                              ),
                              matchRecordReference);
                          if (_model.superMatch == true) {
                            logFirebaseEvent('SwipeableStack_backend_call');

                            firestoreBatch.set(
                                NotificationsRecord.collection.doc(),
                                createNotificationsRecordData(
                                  sender: currentUserReference,
                                  recipient: userFYP[index].reference,
                                  createdAt: getCurrentTimestamp,
                                  type: 'newMatch',
                                ));
                            logFirebaseEvent(
                                'SwipeableStack_trigger_push_notification');
                            triggerPushNotification(
                              notificationTitle: 'Novo Match',
                              notificationText: 'Você tem um novo match.',
                              notificationSound: 'default',
                              userRefs: [userFYP[index].reference],
                              initialPageName: 'NotificationPage',
                              parameterData: {},
                            );
                          }
                          logFirebaseEvent('SwipeableStack_firestore_query');
                          _model.fetchMatch = await queryMatchRecordOnce(
                            queryBuilder: (matchRecord) => matchRecord
                                .where(
                                  'recipient',
                                  isEqualTo: currentUserReference,
                                )
                                .where(
                                  'sender',
                                  isEqualTo: userFYP[index].reference,
                                ),
                            singleRecord: true,
                          ).then((s) => s.firstOrNull);
                          if (_model.fetchMatch?.reference.id != null &&
                              _model.fetchMatch?.reference.id != '') {
                            logFirebaseEvent('SwipeableStack_alert_dialog');
                            await showDialog(
                              barrierColor: FlutterFlowTheme.of(context).navBar,
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: MatchWidget(
                                    otherUser: userFYP[index],
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          }
                          logFirebaseEvent(
                              'SwipeableStack_update_component_state');
                          _model.superMatch = false;
                        } finally {
                          await firestoreBatch.commit();
                        }

                        setState(() {});
                      },
                      onUpSwipe: (index) {},
                      onDownSwipe: (index) {},
                      itemBuilder: (context, userFYPIndex) {
                        final userFYPItem = userFYP[userFYPIndex];
                        return wrapWithModel(
                          model: _model.fYPCardModels.getModel(
                            userFYPItem.uid,
                            userFYPIndex,
                          ),
                          updateCallback: () => setState(() {}),
                          child: FYPCardWidget(
                            key: Key(
                              'Keynfh_${userFYPItem.uid}',
                            ),
                            address: functions.getAddress(
                                _model.addresses.toList(),
                                userFYPItem.address?.id),
                            activityBranch: functions.getActivityBranches(
                                _model.activityBranches.toList(),
                                userFYPItem.activityBranch?.id),
                            user: userFYPItem,
                            noMatch: () async {
                              logFirebaseEvent(
                                  'FYP_COMP_Container_nfh1mq5k_CALLBACK');
                              logFirebaseEvent('FYPCard_swipeable_stack');
                              _model.swipeableStackController.swipeLeft();
                            },
                            superMatch: () async {
                              logFirebaseEvent(
                                  'FYP_COMP_Container_nfh1mq5k_CALLBACK');
                              var shouldSetState = false;
                              logFirebaseEvent('FYPCard_firestore_query');
                              _model.fetchSuperMatches =
                                  await queryMatchRecordOnce(
                                queryBuilder: (matchRecord) => matchRecord
                                    .where(
                                      'sender',
                                      isEqualTo: currentUserReference,
                                    )
                                    .where(
                                      'is_super',
                                      isEqualTo: true,
                                    ),
                                limit: 2,
                              );
                              shouldSetState = true;
                              if (functions.smLimit(
                                  _model.fetchSuperMatches!.toList())) {
                                logFirebaseEvent('FYPCard_action_block');
                                _model.watchedS = await action_blocks.adverts(
                                  context,
                                  showAnyway: true,
                                );
                                shouldSetState = true;
                                if (_model.watchedS!) {
                                  logFirebaseEvent(
                                      'FYPCard_update_component_state');
                                  _model.superMatch = true;
                                  logFirebaseEvent('FYPCard_swipeable_stack');
                                  _model.swipeableStackController.swipeRight();
                                }
                              } else {
                                logFirebaseEvent('FYPCard_show_snack_bar');
                                ScaffoldMessenger.of(context).clearSnackBars();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      'Seus supermatch diários acabaram.',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            color: FlutterFlowTheme.of(context)
                                                .primaryText,
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    duration: const Duration(milliseconds: 2000),
                                    backgroundColor:
                                        FlutterFlowTheme.of(context).alternate,
                                  ),
                                );
                                if (shouldSetState) setState(() {});
                                return;
                              }

                              if (shouldSetState) setState(() {});
                            },
                            match: () async {
                              logFirebaseEvent(
                                  'FYP_COMP_Container_nfh1mq5k_CALLBACK');
                              logFirebaseEvent('FYPCard_action_block');
                              _model.watched =
                                  await action_blocks.adverts(context);
                              if (_model.watched!) {
                                logFirebaseEvent(
                                    'FYPCard_update_component_state');
                                _model.superMatch = false;
                                logFirebaseEvent('FYPCard_swipeable_stack');
                                _model.swipeableStackController.swipeRight();
                              }

                              setState(() {});
                            },
                          ),
                        );
                      },
                      itemCount: userFYP.length,
                      controller: _model.swipeableStackController,
                      loop: false,
                      cardDisplayCount: 3,
                      scale: 0.9,
                    ).animateOnPageLoad(
                        animationsMap['swipeableStackOnPageLoadAnimation']!);
                  },
                ),
              ),
            ),
          );
        } else {
          return wrapWithModel(
            model: _model.finishedModel,
            updateCallback: () => setState(() {}),
            child: const FinishedWidget(),
          );
        }
      },
    );
  }
}
