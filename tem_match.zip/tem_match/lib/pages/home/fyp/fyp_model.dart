import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/home/components/finished/finished_widget.dart';
import '/pages/home/f_y_p_card/f_y_p_card_widget.dart';
import 'fyp_widget.dart' show FypWidget;
import 'package:flutter/material.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';

class FypModel extends FlutterFlowModel<FypWidget> {
  ///  Local state fields for this component.

  bool superMatch = false;

  List<UsersRecord> usersFyp = [];
  void addToUsersFyp(UsersRecord item) => usersFyp.add(item);
  void removeFromUsersFyp(UsersRecord item) => usersFyp.remove(item);
  void removeAtIndexFromUsersFyp(int index) => usersFyp.removeAt(index);
  void insertAtIndexInUsersFyp(int index, UsersRecord item) =>
      usersFyp.insert(index, item);
  void updateUsersFypAtIndex(int index, Function(UsersRecord) updateFn) =>
      usersFyp[index] = updateFn(usersFyp[index]);

  int? aux = 0;

  List<AddressesRecord> addresses = [];
  void addToAddresses(AddressesRecord item) => addresses.add(item);
  void removeFromAddresses(AddressesRecord item) => addresses.remove(item);
  void removeAtIndexFromAddresses(int index) => addresses.removeAt(index);
  void insertAtIndexInAddresses(int index, AddressesRecord item) =>
      addresses.insert(index, item);
  void updateAddressesAtIndex(int index, Function(AddressesRecord) updateFn) =>
      addresses[index] = updateFn(addresses[index]);

  List<ActivityBranchesRecord> activityBranches = [];
  void addToActivityBranches(ActivityBranchesRecord item) =>
      activityBranches.add(item);
  void removeFromActivityBranches(ActivityBranchesRecord item) =>
      activityBranches.remove(item);
  void removeAtIndexFromActivityBranches(int index) =>
      activityBranches.removeAt(index);
  void insertAtIndexInActivityBranches(
          int index, ActivityBranchesRecord item) =>
      activityBranches.insert(index, item);
  void updateActivityBranchesAtIndex(
          int index, Function(ActivityBranchesRecord) updateFn) =>
      activityBranches[index] = updateFn(activityBranches[index]);

  bool isFinished = false;

  bool isLoaded = false;

  ///  State fields for stateful widgets in this component.

  // Stores action output result for [Firestore Query - Query a collection] action in FYP widget.
  List<UsersRecord>? fetchUsers;
  // Stores action output result for [Firestore Query - Query a collection] action in FYP widget.
  List<AddressesRecord>? fetchAddresses;
  // Stores action output result for [Firestore Query - Query a collection] action in FYP widget.
  List<ActivityBranchesRecord>? fetchActivityBranches;
  // State field(s) for SwipeableStack widget.
  late CardSwiperController swipeableStackController;
  // Stores action output result for [Firestore Query - Query a collection] action in SwipeableStack widget.
  ViewsOnFypRecord? fetchView;
  // Stores action output result for [Backend Call - Create Document] action in SwipeableStack widget.
  MatchRecord? newMatch;
  // Stores action output result for [Firestore Query - Query a collection] action in SwipeableStack widget.
  MatchRecord? fetchMatch;
  // Models for FYPCard dynamic component.
  late FlutterFlowDynamicModels<FYPCardModel> fYPCardModels;
  // Stores action output result for [Action Block - Adverts] action in FYPCard widget.
  bool? watched;
  // Stores action output result for [Firestore Query - Query a collection] action in FYPCard widget.
  List<MatchRecord>? fetchSuperMatches;
  // Stores action output result for [Action Block - Adverts] action in FYPCard widget.
  bool? watchedS;
  // Model for Finished component.
  late FinishedModel finishedModel;

  @override
  void initState(BuildContext context) {
    swipeableStackController = CardSwiperController();
    fYPCardModels = FlutterFlowDynamicModels(() => FYPCardModel());
    finishedModel = createModel(context, () => FinishedModel());
  }

  @override
  void dispose() {
    fYPCardModels.dispose();
    finishedModel.dispose();
  }
}
