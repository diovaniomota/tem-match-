import '/flutter_flow/flutter_flow_util.dart';
import 'match_widget.dart' show MatchWidget;
import 'package:flutter/material.dart';

class MatchModel extends FlutterFlowModel<MatchWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
