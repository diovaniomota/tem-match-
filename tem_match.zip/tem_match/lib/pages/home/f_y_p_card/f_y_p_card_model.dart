import '/flutter_flow/flutter_flow_util.dart';
import 'f_y_p_card_widget.dart' show FYPCardWidget;
import 'package:flutter/material.dart';

class FYPCardModel extends FlutterFlowModel<FYPCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
