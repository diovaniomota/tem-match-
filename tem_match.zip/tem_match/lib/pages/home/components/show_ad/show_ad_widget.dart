import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_media_display.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_timer.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_video_player.dart';
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'show_ad_model.dart';
export 'show_ad_model.dart';

class ShowAdWidget extends StatefulWidget {
  const ShowAdWidget({
    super.key,
    required this.advert,
  });

  final AdvertsRecord? advert;

  @override
  State<ShowAdWidget> createState() => _ShowAdWidgetState();
}

class _ShowAdWidgetState extends State<ShowAdWidget> {
  late ShowAdModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ShowAdModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      logFirebaseEvent('SHOW_AD_COMP_ShowAd_ON_INIT_STATE');
      logFirebaseEvent('ShowAd_backend_call');

      await ViewsAdRecord.createDoc(widget.advert!.reference)
          .set(createViewsAdRecordData(
        createdAt: getCurrentTimestamp,
        viewer: currentUserReference,
      ));
      logFirebaseEvent('ShowAd_timer');
      _model.timerController.onResetTimer();

      logFirebaseEvent('ShowAd_timer');
      _model.timerController.onStartTimer();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Flexible(
                child: Text(
                  valueOrDefault<String>(
                    widget.advert?.name,
                    'Advert',
                  ),
                  style: FlutterFlowTheme.of(context).titleMedium.override(
                        fontFamily: 'Readex Pro',
                        color: FlutterFlowTheme.of(context).primaryText,
                        letterSpacing: 0.0,
                      ),
                ),
              ),
              Builder(
                builder: (context) {
                  if (!_model.close) {
                    return Align(
                      alignment: const AlignmentDirectional(0.0, 0.0),
                      child: Container(
                        width: 40.0,
                        height: 40.0,
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).alternate,
                          shape: BoxShape.circle,
                        ),
                        child: Align(
                          alignment: const AlignmentDirectional(0.0, 0.0),
                          child: FlutterFlowTimer(
                            initialTime:
                                getRemoteConfigInt('mandatory_ad_time') * 1000,
                            getDisplayTime: (value) =>
                                StopWatchTimer.getDisplayTime(
                              value,
                              hours: false,
                              minute: false,
                              milliSecond: false,
                            ),
                            controller: _model.timerController,
                            updateStateInterval: const Duration(milliseconds: 1000),
                            onChanged: (value, displayTime, shouldUpdate) {
                              _model.timerMilliseconds = value;
                              _model.timerValue = displayTime;
                              if (shouldUpdate) setState(() {});
                            },
                            onEnded: () async {
                              logFirebaseEvent(
                                  'SHOW_AD_COMP_Timer_1v7848mr_ON_TIMER_END');
                              logFirebaseEvent('Timer_update_component_state');
                              setState(() {
                                _model.close = true;
                              });
                            },
                            textAlign: TextAlign.start,
                            style: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'Readex Pro',
                                  letterSpacing: 0.0,
                                ),
                          ),
                        ),
                      ),
                    );
                  } else {
                    return FlutterFlowIconButton(
                      borderColor: Colors.transparent,
                      borderRadius: 20.0,
                      borderWidth: 1.0,
                      buttonSize: 40.0,
                      fillColor: FlutterFlowTheme.of(context).alternate,
                      icon: Icon(
                        Icons.close_rounded,
                        color: FlutterFlowTheme.of(context).primaryText,
                        size: 24.0,
                      ),
                      onPressed: () async {
                        logFirebaseEvent(
                            'SHOW_AD_COMP_close_rounded_ICN_ON_TAP');
                        logFirebaseEvent('IconButton_dismiss_dialog');
                        Navigator.pop(context, true);
                      },
                    );
                  }
                },
              ),
            ].divide(const SizedBox(width: 12.0)),
          ),
          Expanded(
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(),
              alignment: const AlignmentDirectional(0.0, 0.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onTap: () async {
                        logFirebaseEvent('SHOW_AD_COMP_Ad_ON_TAP');
                        if (widget.advert!.hasLink()) {
                          logFirebaseEvent('Ad_launch_u_r_l');
                          await launchURL(widget.advert!.link);
                        }
                      },
                      child: Container(
                        decoration: const BoxDecoration(),
                        child: Builder(
                          builder: (context) {
                            if (widget.advert?.hasMediaUrl() ?? false) {
                              return Align(
                                alignment: const AlignmentDirectional(0.0, 0.0),
                                child: FlutterFlowMediaDisplay(
                                  path: widget.advert!.mediaUrl,
                                  imageBuilder: (path) => ClipRRect(
                                    borderRadius: BorderRadius.circular(4.0),
                                    child: Image.network(
                                      path,
                                      width: double.infinity,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  videoPlayerBuilder: (path) =>
                                      FlutterFlowVideoPlayer(
                                    path: path,
                                    width: 300.0,
                                    autoPlay: true,
                                    looping: true,
                                    showControls: false,
                                    allowFullScreen: false,
                                    allowPlaybackSpeedMenu: false,
                                  ),
                                ),
                              );
                            } else {
                              return Container(
                                decoration: const BoxDecoration(),
                                child: Text(
                                  'No ad',
                                  textAlign: TextAlign.center,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              );
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          InkWell(
            splashColor: Colors.transparent,
            focusColor: Colors.transparent,
            hoverColor: Colors.transparent,
            highlightColor: Colors.transparent,
            onTap: () async {
              logFirebaseEvent('SHOW_AD_COMP_Text_5zuzqk0q_ON_TAP');
              if (widget.advert?.link != null && widget.advert?.link != '') {
                logFirebaseEvent('Text_launch_u_r_l');
                await launchURL(widget.advert!.link);
              }
            },
            child: Text(
              'Saiba mais',
              style: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Readex Pro',
                    color: FlutterFlowTheme.of(context).secondaryText,
                    letterSpacing: 0.0,
                    decoration: TextDecoration.underline,
                  ),
            ),
          ),
        ].divide(const SizedBox(height: 16.0)),
      ),
    );
  }
}
