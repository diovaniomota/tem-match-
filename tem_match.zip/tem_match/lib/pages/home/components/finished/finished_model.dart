import '/flutter_flow/flutter_flow_util.dart';
import 'finished_widget.dart' show FinishedWidget;
import 'package:flutter/material.dart';

class FinishedModel extends FlutterFlowModel<FinishedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
