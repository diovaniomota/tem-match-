import '/flutter_flow/flutter_flow_util.dart';
import '/pages/home/components/show_ad/show_ad_widget.dart';
import 'advert_widget.dart' show AdvertWidget;
import 'package:flutter/material.dart';

class AdvertModel extends FlutterFlowModel<AdvertWidget> {
  ///  Local state fields for this component.

  bool show = false;

  ///  State fields for stateful widgets in this component.

  // Model for ShowAd component.
  late ShowAdModel showAdModel;

  @override
  void initState(BuildContext context) {
    showAdModel = createModel(context, () => ShowAdModel());
  }

  @override
  void dispose() {
    showAdModel.dispose();
  }
}
