import '/flutter_flow/flutter_flow_util.dart';
import 'terms_and_privacy_page_widget.dart' show TermsAndPrivacyPageWidget;
import 'package:flutter/material.dart';

class TermsAndPrivacyPageModel
    extends FlutterFlowModel<TermsAndPrivacyPageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
