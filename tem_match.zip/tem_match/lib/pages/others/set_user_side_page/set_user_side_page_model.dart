import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'set_user_side_page_widget.dart' show SetUserSidePageWidget;
import 'package:flutter/material.dart';

class SetUserSidePageModel extends FlutterFlowModel<SetUserSidePageWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }

  /// Action blocks.
  Future investor(BuildContext context) async {
    logFirebaseEvent('Investor_backend_call');

    await currentUserReference!.update(createUsersRecordData(
      side: 'investor',
    ));
    logFirebaseEvent('Investor_navigate_to');

    context.goNamed(
      'EditProfilePage',
      queryParameters: {
        'first': serializeParam(
          true,
          ParamType.bool,
        ),
      }.withoutNulls,
      extra: <String, dynamic>{
        kTransitionInfoKey: const TransitionInfo(
          hasTransition: true,
          transitionType: PageTransitionType.rightToLeft,
        ),
      },
    );
  }

  Future startup(BuildContext context) async {
    logFirebaseEvent('Startup_navigate_to');

    context.goNamed(
      'EditProfilePage',
      queryParameters: {
        'first': serializeParam(
          true,
          ParamType.bool,
        ),
      }.withoutNulls,
      extra: <String, dynamic>{
        kTransitionInfoKey: const TransitionInfo(
          hasTransition: true,
          transitionType: PageTransitionType.rightToLeft,
        ),
      },
    );
  }
}
