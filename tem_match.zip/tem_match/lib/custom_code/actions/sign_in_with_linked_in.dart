// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:linkedin_login/linkedin_login.dart';

const String _REDIRECT_URL = 'https://www.temmatch.com/callback';
const String _CLIENT_ID = '77arjnd07cp5iw';
const String _CLIENT_SECRET = 'wx1VIYYBcsl4IWkf';

Future signInWithLinkedIn(BuildContext context) async {
  if (kIsWeb) return;
  final String? accessToken = await _signInWithPopup(context);
  if (accessToken != null) {
    final User? user = await _linkedInSignIn(context, accessToken);
  }
}

Future<String?> _signInWithPopup(BuildContext context) async {
  return await Navigator.push(
    context,
    MaterialPageRoute(
      builder: (BuildContext context) {
        return LinkedInUserWidget(
          appBar: AppBar(title: const Text('Login With LinkedIn')),
          destroySession: true,
          redirectUrl: _REDIRECT_URL,
          clientId: _CLIENT_ID,
          clientSecret: _CLIENT_SECRET,
          onError: (UserFailedAction e) {},
          onGetUserProfile: (UserSucceededAction linkedInUser) {
            final LinkedInTokenObject token = linkedInUser.user.token;
            Navigator.pop(context, token.accessToken);
          },
        );
      },
    ),
  );
}

Future<User?> _linkedInSignIn(BuildContext context, String accessToken) async {
  try {
    final OAuthCredential credential =
        OAuthProvider("linkedin.com").credential(accessToken: accessToken);
    final UserCredential userCredential =
        await FirebaseAuth.instance.signInWithCredential(credential);
    final User? user = userCredential.user;
    if (user != null) await maybeCreateUser(user);
    return user;
  } on FirebaseAuthException catch (e) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error: ${e.message!}')),
    );
    return null;
  }
}
