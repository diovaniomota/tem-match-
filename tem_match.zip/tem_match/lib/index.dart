// Export pages
export '/pages/home/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/auth/sign_in_page/sign_in_page_widget.dart'
    show SignInPageWidget;
export '/pages/others/welcome_page/welcome_page_widget.dart'
    show WelcomePageWidget;
export '/pages/auth/sign_up_page/sign_up_page_widget.dart'
    show SignUpPageWidget;
export '/pages/profile/profile_page/profile_page_widget.dart'
    show ProfilePageWidget;
export '/pages/others/set_user_side_page/set_user_side_page_widget.dart'
    show SetUserSidePageWidget;
export '/pages/auth/forgot_password/forgot_password_widget.dart'
    show ForgotPasswordWidget;
export '/pages/profile/settings_page/settings_page_widget.dart'
    show SettingsPageWidget;
export '/pages/notification/notification_page/notification_page_widget.dart'
    show NotificationPageWidget;
export '/pages/notification/notifications_settings_page/notifications_settings_page_widget.dart'
    show NotificationsSettingsPageWidget;
export '/pages/others/terms_and_privacy_page/terms_and_privacy_page_widget.dart'
    show TermsAndPrivacyPageWidget;
export '/pages/profile/edit_profile_page/edit_profile_page_widget.dart'
    show EditProfilePageWidget;
export '/pages/account/reset_password_page/reset_password_page_widget.dart'
    show ResetPasswordPageWidget;
export '/pages/account/change_email_page/change_email_page_widget.dart'
    show ChangeEmailPageWidget;
export '/pages/account/account_page/account_page_widget.dart'
    show AccountPageWidget;
export '/pages/account/phone_number_page/phone_number_page_widget.dart'
    show PhoneNumberPageWidget;
export '/pages/others/support_page/support_page_widget.dart'
    show SupportPageWidget;
export '/pages/others/report_page/report_page_widget.dart'
    show ReportPageWidget;
export '/pages/user_info_page/user_info_page_widget.dart'
    show UserInfoPageWidget;
export '/pages/chat/chat_page/chat_page_widget.dart' show ChatPageWidget;
export '/pages/chat/all_chats_page/all_chats_page_widget.dart'
    show AllChatsPageWidget;
export '/pages/chat/add_chat_users_page/add_chat_users_page_widget.dart'
    show AddChatUsersPageWidget;
export '/admin/dashboard/dashboard_page/dashboard_page_widget.dart'
    show DashboardPageWidget;
export '/pages/others/tags1_page/tags1_page_widget.dart' show Tags1PageWidget;
export '/pages/others/tags2_page/tags2_page_widget.dart' show Tags2PageWidget;
export '/pages/others/f_ilter_page/f_ilter_page_widget.dart'
    show FIlterPageWidget;
export '/admin/welcome/welcome_management_page/welcome_management_page_widget.dart'
    show WelcomeManagementPageWidget;
export '/admin/report_manager/reports_page/reports_page_widget.dart'
    show ReportsPageWidget;
export '/admin/dashboard/f_a_qs_page/f_a_qs_page_widget.dart'
    show FAQsPageWidget;
export '/admin/ads_manager/ads_page/ads_page_widget.dart' show AdsPageWidget;
export '/admin/answer_bank/answer_bank_page/answer_bank_page_widget.dart'
    show AnswerBankPageWidget;
export '/admin/ads_manager/add_ads_page/add_ads_page_widget.dart'
    show AddAdsPageWidget;
export '/admin/answer_bank/show_users_page/show_users_page_widget.dart'
    show ShowUsersPageWidget;
export '/admin/adms/a_d_ms_page/a_d_ms_page_widget.dart' show ADMsPageWidget;
export '/pages/others/delete_account_page/delete_account_page_widget.dart'
    show DeleteAccountPageWidget;
export '/pages/others/banned_user_page/banned_user_page_widget.dart'
    show BannedUserPageWidget;
export '/pages/others/terms_e_u_l_a_page/terms_e_u_l_a_page_widget.dart'
    show TermsEULAPageWidget;
export '/admin/edit_tags/edit_tag_page/edit_tag_page_widget.dart'
    show EditTagPageWidget;
