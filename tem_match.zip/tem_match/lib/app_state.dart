import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _pushNotifications =
          prefs.getBool('ff_pushNotifications') ?? _pushNotifications;
    });
    _safeInit(() {
      _ad = prefs.getInt('ff_ad') ?? _ad;
    });
    _safeInit(() {
      if (prefs.containsKey('ff_location')) {
        try {
          final serializedData = prefs.getString('ff_location') ?? '{}';
          _location =
              AddressStruct.fromSerializableMap(jsonDecode(serializedData));
        } catch (e) {
          print("Can't decode persisted data type. Error: $e.");
        }
      }
    });
    _safeInit(() {
      _acitivityBranchID =
          prefs.getString('ff_acitivityBranchID') ?? _acitivityBranchID;
    });
    _safeInit(() {
      _faseStartupID = prefs.getString('ff_faseStartupID') ?? _faseStartupID;
    });
    _safeInit(() {
      _valuationStartupID =
          prefs.getString('ff_valuationStartupID') ?? _valuationStartupID;
    });
    _safeInit(() {
      _question1 = prefs.getString('ff_question1') ?? _question1;
    });
    _safeInit(() {
      _question2 = prefs.getString('ff_question2') ?? _question2;
    });
    _safeInit(() {
      _question3 = prefs.getString('ff_question3') ?? _question3;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _pushNotifications = true;
  bool get pushNotifications => _pushNotifications;
  set pushNotifications(bool value) {
    _pushNotifications = value;
    prefs.setBool('ff_pushNotifications', value);
  }

  int _ad = 0;
  int get ad => _ad;
  set ad(int value) {
    _ad = value;
    prefs.setInt('ff_ad', value);
  }

  AddressStruct _location = AddressStruct();
  AddressStruct get location => _location;
  set location(AddressStruct value) {
    _location = value;
    prefs.setString('ff_location', value.serialize());
  }

  void updateLocationStruct(Function(AddressStruct) updateFn) {
    updateFn(_location);
    prefs.setString('ff_location', _location.serialize());
  }

  String _acitivityBranchID = '';
  String get acitivityBranchID => _acitivityBranchID;
  set acitivityBranchID(String value) {
    _acitivityBranchID = value;
    prefs.setString('ff_acitivityBranchID', value);
  }

  String _faseStartupID = '';
  String get faseStartupID => _faseStartupID;
  set faseStartupID(String value) {
    _faseStartupID = value;
    prefs.setString('ff_faseStartupID', value);
  }

  String _valuationStartupID = '';
  String get valuationStartupID => _valuationStartupID;
  set valuationStartupID(String value) {
    _valuationStartupID = value;
    prefs.setString('ff_valuationStartupID', value);
  }

  String _question1 = '';
  String get question1 => _question1;
  set question1(String value) {
    _question1 = value;
    prefs.setString('ff_question1', value);
  }

  String _question2 = '';
  String get question2 => _question2;
  set question2(String value) {
    _question2 = value;
    prefs.setString('ff_question2', value);
  }

  String _question3 = '';
  String get question3 => _question3;
  set question3(String value) {
    _question3 = value;
    prefs.setString('ff_question3', value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
