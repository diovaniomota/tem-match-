import '/flutter_flow/flutter_flow_util.dart';
import 'new_f_a_q_widget.dart' show NewFAQWidget;
import 'package:flutter/material.dart';

class NewFAQModel extends FlutterFlowModel<NewFAQWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for title widget.
  FocusNode? titleFocusNode;
  TextEditingController? titleController;
  String? Function(BuildContext, String?)? titleControllerValidator;
  String? _titleControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  // State field(s) for content widget.
  FocusNode? contentFocusNode;
  TextEditingController? contentController;
  String? Function(BuildContext, String?)? contentControllerValidator;
  String? _contentControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    titleControllerValidator = _titleControllerValidator;
    contentControllerValidator = _contentControllerValidator;
  }

  @override
  void dispose() {
    titleFocusNode?.dispose();
    titleController?.dispose();

    contentFocusNode?.dispose();
    contentController?.dispose();
  }
}
