import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'new_tag_widget.dart' show NewTagWidget;
import 'package:flutter/material.dart';

class NewTagModel extends FlutterFlowModel<NewTagWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for tag widget.
  FocusNode? tagFocusNode;
  TextEditingController? tagController;
  String? Function(BuildContext, String?)? tagControllerValidator;
  String? _tagControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  // State field(s) for side widget.
  String? sideValue;
  FormFieldController<String>? sideValueController;

  @override
  void initState(BuildContext context) {
    tagControllerValidator = _tagControllerValidator;
  }

  @override
  void dispose() {
    tagFocusNode?.dispose();
    tagController?.dispose();
  }
}
