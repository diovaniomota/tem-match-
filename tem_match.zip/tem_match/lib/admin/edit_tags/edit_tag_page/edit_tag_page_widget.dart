import '/admin/edit_tags/components/new_tag/new_tag_widget.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'edit_tag_page_model.dart';
export 'edit_tag_page_model.dart';

class EditTagPageWidget extends StatefulWidget {
  const EditTagPageWidget({super.key});

  @override
  State<EditTagPageWidget> createState() => _EditTagPageWidgetState();
}

class _EditTagPageWidgetState extends State<EditTagPageWidget> {
  late EditTagPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EditTagPageModel());

    logFirebaseEvent('screen_view', parameters: {'screen_name': 'EditTagPage'});
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).appBarBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: FaIcon(
              FontAwesomeIcons.angleLeft,
              color: FlutterFlowTheme.of(context).info,
              size: 30.0,
            ),
            onPressed: () async {
              logFirebaseEvent('EDIT_TAG_PAGE_PAGE_angleLeft_ICN_ON_TAP');
              logFirebaseEvent('IconButton_navigate_back');
              context.pop();
            },
          ),
          title: Text(
            'Editar Tags',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: FlutterFlowTheme.of(context).info,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            image: DecorationImage(
              fit: BoxFit.cover,
              image: Image.asset(
                'assets/images/Background.jpg',
              ).image,
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'O que ofereço',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'EDIT_TAG_PAGE_PAGE_Text_ipzslmj6_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewTagWidget(
                                      type: 'tags_1',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<Tags1Record>>(
                  stream: queryTags1Record(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<Tags1Record> columnTags1RecordList = snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: List.generate(columnTags1RecordList.length,
                          (columnIndex) {
                        final columnTags1Record =
                            columnTags1RecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: Slidable(
                            endActionPane: ActionPane(
                              motion: const ScrollMotion(),
                              extentRatio: 0.25,
                              children: [
                                SlidableAction(
                                  label: 'Deletar',
                                  backgroundColor:
                                      FlutterFlowTheme.of(context).error,
                                  icon: FontAwesomeIcons.solidTrashAlt,
                                  onPressed: (_) async {
                                    logFirebaseEvent(
                                        'EDIT_TAG_SlidableActionWidget_a539sbbw_O');
                                    logFirebaseEvent(
                                        'SlidableActionWidget_backend_call');
                                    await columnTags1Record.reference.delete();
                                  },
                                ),
                              ],
                            ),
                            child: ListTile(
                              title: Text(
                                columnTags1Record.name,
                                style: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              subtitle: Text(
                                columnTags1Record.side,
                                style: FlutterFlowTheme.of(context)
                                    .labelSmall
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              dense: false,
                            ),
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'O que procuro',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'EDIT_TAG_PAGE_PAGE_Text_z34m3fiu_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewTagWidget(
                                      type: 'tags_2',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<Tags2Record>>(
                  stream: queryTags2Record(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<Tags2Record> columnTags2RecordList = snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: List.generate(columnTags2RecordList.length,
                          (columnIndex) {
                        final columnTags2Record =
                            columnTags2RecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: Slidable(
                            endActionPane: ActionPane(
                              motion: const ScrollMotion(),
                              extentRatio: 0.25,
                              children: [
                                SlidableAction(
                                  label: 'Deletar',
                                  backgroundColor:
                                      FlutterFlowTheme.of(context).error,
                                  icon: FontAwesomeIcons.solidTrashAlt,
                                  onPressed: (_) async {
                                    logFirebaseEvent(
                                        'EDIT_TAG_SlidableActionWidget_vpbe8ai1_O');
                                    logFirebaseEvent(
                                        'SlidableActionWidget_backend_call');
                                    await columnTags2Record.reference.delete();
                                  },
                                ),
                              ],
                            ),
                            child: ListTile(
                              title: Text(
                                columnTags2Record.name,
                                style: FlutterFlowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              subtitle: Text(
                                columnTags2Record.side,
                                style: FlutterFlowTheme.of(context)
                                    .labelSmall
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      letterSpacing: 0.0,
                                    ),
                              ),
                              dense: false,
                            ),
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
              ].divide(const SizedBox(height: 16.0)).around(const SizedBox(height: 16.0)),
            ),
          ),
        ),
      ),
    );
  }
}
