import '/flutter_flow/flutter_flow_util.dart';
import 'new_label_widget.dart' show NewLabelWidget;
import 'package:flutter/material.dart';

class NewLabelModel extends FlutterFlowModel<NewLabelWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for title widget.
  FocusNode? titleFocusNode;
  TextEditingController? titleController;
  String? Function(BuildContext, String?)? titleControllerValidator;
  String? _titleControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.isEmpty) {
      return 'Requires at least 1 characters.';
    }
    if (val.length > 60) {
      return 'Maximum 60 characters allowed, currently ${val.length}.';
    }

    return null;
  }

  // State field(s) for subtitle widget.
  FocusNode? subtitleFocusNode;
  TextEditingController? subtitleController;
  String? Function(BuildContext, String?)? subtitleControllerValidator;
  String? _subtitleControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    if (val.isEmpty) {
      return 'Requires at least 1 characters.';
    }
    if (val.length > 60) {
      return 'Maximum 60 characters allowed, currently ${val.length}.';
    }

    return null;
  }

  // State field(s) for CountController widget.
  int? countControllerValue;

  @override
  void initState(BuildContext context) {
    titleControllerValidator = _titleControllerValidator;
    subtitleControllerValidator = _subtitleControllerValidator;
  }

  @override
  void dispose() {
    titleFocusNode?.dispose();
    titleController?.dispose();

    subtitleFocusNode?.dispose();
    subtitleController?.dispose();
  }
}
