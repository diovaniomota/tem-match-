import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dashboard_page_widget.dart' show DashboardPageWidget;
import 'package:flutter/material.dart';

class DashboardPageModel extends FlutterFlowModel<DashboardPageWidget> {
  ///  Local state fields for this page.

  List<String> labels = [];
  void addToLabels(String item) => labels.add(item);
  void removeFromLabels(String item) => labels.remove(item);
  void removeAtIndexFromLabels(int index) => labels.removeAt(index);
  void insertAtIndexInLabels(int index, String item) =>
      labels.insert(index, item);
  void updateLabelsAtIndex(int index, Function(String) updateFn) =>
      labels[index] = updateFn(labels[index]);

  List<double> numbers = [];
  void addToNumbers(double item) => numbers.add(item);
  void removeFromNumbers(double item) => numbers.remove(item);
  void removeAtIndexFromNumbers(int index) => numbers.removeAt(index);
  void insertAtIndexInNumbers(int index, double item) =>
      numbers.insert(index, item);
  void updateNumbersAtIndex(int index, Function(double) updateFn) =>
      numbers[index] = updateFn(numbers[index]);

  int matches = 0;

  int supermatches = 0;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }

  /// Action blocks.
  Future loadUsers(BuildContext context) async {
    int? countStartup;
    int? countInvestor;

    logFirebaseEvent('LoadUsers_firestore_query');
    countStartup = await queryUsersRecordCount(
      queryBuilder: (usersRecord) => usersRecord.where(
        'side',
        isEqualTo: 'startup',
      ),
    );
    logFirebaseEvent('LoadUsers_firestore_query');
    countInvestor = await queryUsersRecordCount(
      queryBuilder: (usersRecord) => usersRecord.where(
        'side',
        isEqualTo: 'investor',
      ),
    );
    logFirebaseEvent('LoadUsers_update_page_state');
    addToNumbers(countStartup.toDouble());
    logFirebaseEvent('LoadUsers_update_page_state');
    addToNumbers(countInvestor.toDouble());
    logFirebaseEvent('LoadUsers_update_page_state');
    addToLabels('Startup');
    logFirebaseEvent('LoadUsers_update_page_state');
    addToLabels('Investidor');
  }

  Future loadMatches(BuildContext context) async {
    int? countMatches;
    int? countSupermatches;

    logFirebaseEvent('LoadMatches_firestore_query');
    countMatches = await queryMatchRecordCount(
      queryBuilder: (matchRecord) => matchRecord.where(
        'is_super',
        isEqualTo: false,
      ),
    );
    logFirebaseEvent('LoadMatches_firestore_query');
    countSupermatches = await queryMatchRecordCount(
      queryBuilder: (matchRecord) => matchRecord.where(
        'is_super',
        isEqualTo: true,
      ),
    );
    logFirebaseEvent('LoadMatches_update_page_state');
    matches = countMatches;
    supermatches = countSupermatches;
  }
}
