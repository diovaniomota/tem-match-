import '/flutter_flow/flutter_flow_util.dart';
import 'new_answer_widget.dart' show NewAnswerWidget;
import 'package:flutter/material.dart';

class NewAnswerModel extends FlutterFlowModel<NewAnswerWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  // State field(s) for answer widget.
  FocusNode? answerFocusNode;
  TextEditingController? answerController;
  String? Function(BuildContext, String?)? answerControllerValidator;
  String? _answerControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    answerControllerValidator = _answerControllerValidator;
  }

  @override
  void dispose() {
    answerFocusNode?.dispose();
    answerController?.dispose();
  }
}
