import '/admin/answer_bank/components/new_answer/new_answer_widget.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'answer_bank_page_model.dart';
export 'answer_bank_page_model.dart';

class AnswerBankPageWidget extends StatefulWidget {
  const AnswerBankPageWidget({super.key});

  @override
  State<AnswerBankPageWidget> createState() => _AnswerBankPageWidgetState();
}

class _AnswerBankPageWidgetState extends State<AnswerBankPageWidget> {
  late AnswerBankPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AnswerBankPageModel());

    logFirebaseEvent('screen_view',
        parameters: {'screen_name': 'AnswerBankPage'});
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).appBarBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: FaIcon(
              FontAwesomeIcons.angleLeft,
              color: FlutterFlowTheme.of(context).info,
              size: 30.0,
            ),
            onPressed: () async {
              logFirebaseEvent('ANSWER_BANK_angleLeft_ICN_ON_TAP');
              logFirebaseEvent('IconButton_navigate_back');
              context.pop();
            },
          ),
          title: Text(
            'Banco de Respostas',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: FlutterFlowTheme.of(context).info,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            image: DecorationImage(
              fit: BoxFit.cover,
              image: Image.asset(
                'assets/images/Background.jpg',
              ).image,
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'Modelo de Negócio',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'ANSWER_BANK_Text_yyn2wyvp_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewAnswerWidget(
                                      type: 'activity_branch',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<ActivityBranchesRecord>>(
                  stream: queryActivityBranchesRecord(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<ActivityBranchesRecord>
                        columnActivityBranchesRecordList = snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children:
                          List.generate(columnActivityBranchesRecordList.length,
                              (columnIndex) {
                        final columnActivityBranchesRecord =
                            columnActivityBranchesRecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: FutureBuilder<List<UsersRecord>>(
                            future: queryUsersRecordOnce(
                              queryBuilder: (usersRecord) => usersRecord.where(
                                'activity_branch',
                                isEqualTo:
                                    columnActivityBranchesRecord.reference,
                              ),
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return const Center(
                                  child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.transparent,
                                      ),
                                    ),
                                  ),
                                );
                              }
                              List<UsersRecord> listTileUsersRecordList =
                                  snapshot.data!;
                              return InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'ANSWER_BANK_ListTile_zlxz1fk0_ON_TAP');
                                  if (listTileUsersRecordList.isNotEmpty) {
                                    logFirebaseEvent('ListTile_navigate_to');

                                    context.pushNamed(
                                      'ShowUsersPage',
                                      queryParameters: {
                                        'title': serializeParam(
                                          columnActivityBranchesRecord.name,
                                          ParamType.String,
                                        ),
                                        'users': serializeParam(
                                          listTileUsersRecordList,
                                          ParamType.Document,
                                          true,
                                        ),
                                      }.withoutNulls,
                                      extra: <String, dynamic>{
                                        'users': listTileUsersRecordList,
                                        kTransitionInfoKey: const TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.rightToLeft,
                                        ),
                                      },
                                    );
                                  }
                                },
                                child: Slidable(
                                  endActionPane: ActionPane(
                                    motion: const ScrollMotion(),
                                    extentRatio: 0.25,
                                    children: [
                                      SlidableAction(
                                        label: 'Deletar',
                                        backgroundColor:
                                            FlutterFlowTheme.of(context).error,
                                        icon: FontAwesomeIcons.solidTrashAlt,
                                        onPressed: (_) async {
                                          logFirebaseEvent(
                                              'ANSWER_BANK_SlidableActionWidget_ftf1a0e');
                                          logFirebaseEvent(
                                              'SlidableActionWidget_backend_call');
                                          await columnActivityBranchesRecord
                                              .reference
                                              .delete();
                                        },
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      columnActivityBranchesRecord.name,
                                      style: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    subtitle: Text(
                                      listTileUsersRecordList.isEmpty
                                          ? 'Ninguém respondeu'
                                          : '${valueOrDefault<String>(
                                              listTileUsersRecordList.length
                                                  .toString(),
                                              '0',
                                            )} ${listTileUsersRecordList.length > 1 ? 'responderam' : 'respondeu'}',
                                      style: FlutterFlowTheme.of(context)
                                          .labelSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    dense: false,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'Fase da Startup',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'ANSWER_BANK_Text_z5psh5b1_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewAnswerWidget(
                                      type: 'fase_startup',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<FaseStartupRecord>>(
                  stream: queryFaseStartupRecord(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<FaseStartupRecord> columnFaseStartupRecordList =
                        snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: List.generate(
                          columnFaseStartupRecordList.length, (columnIndex) {
                        final columnFaseStartupRecord =
                            columnFaseStartupRecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: FutureBuilder<List<UsersRecord>>(
                            future: queryUsersRecordOnce(
                              queryBuilder: (usersRecord) => usersRecord.where(
                                'fase_startup',
                                isEqualTo: columnFaseStartupRecord.reference,
                              ),
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return const Center(
                                  child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.transparent,
                                      ),
                                    ),
                                  ),
                                );
                              }
                              List<UsersRecord> listTileUsersRecordList =
                                  snapshot.data!;
                              return InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'ANSWER_BANK_ListTile_ejgs7yrq_ON_TAP');
                                  if (listTileUsersRecordList.isNotEmpty) {
                                    logFirebaseEvent('ListTile_navigate_to');

                                    context.pushNamed(
                                      'ShowUsersPage',
                                      queryParameters: {
                                        'title': serializeParam(
                                          columnFaseStartupRecord.name,
                                          ParamType.String,
                                        ),
                                        'users': serializeParam(
                                          listTileUsersRecordList,
                                          ParamType.Document,
                                          true,
                                        ),
                                      }.withoutNulls,
                                      extra: <String, dynamic>{
                                        'users': listTileUsersRecordList,
                                        kTransitionInfoKey: const TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.rightToLeft,
                                        ),
                                      },
                                    );
                                  }
                                },
                                child: Slidable(
                                  endActionPane: ActionPane(
                                    motion: const ScrollMotion(),
                                    extentRatio: 0.25,
                                    children: [
                                      SlidableAction(
                                        label: 'Deletar',
                                        backgroundColor:
                                            FlutterFlowTheme.of(context).error,
                                        icon: FontAwesomeIcons.solidTrashAlt,
                                        onPressed: (_) async {
                                          logFirebaseEvent(
                                              'ANSWER_BANK_SlidableActionWidget_jmvi7q3');
                                          logFirebaseEvent(
                                              'SlidableActionWidget_backend_call');
                                          await columnFaseStartupRecord
                                              .reference
                                              .delete();
                                        },
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      columnFaseStartupRecord.name,
                                      style: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    subtitle: Text(
                                      listTileUsersRecordList.isEmpty
                                          ? 'Ninguém respondeu'
                                          : '${valueOrDefault<String>(
                                              listTileUsersRecordList.length
                                                  .toString(),
                                              '0',
                                            )} ${listTileUsersRecordList.length > 1 ? 'responderam' : 'respondeu'}',
                                      style: FlutterFlowTheme.of(context)
                                          .labelSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    dense: false,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'Valuation da Startup',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'ANSWER_BANK_Text_01u0wvfh_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewAnswerWidget(
                                      type: 'valuation_startup',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<ValuationStartupRecord>>(
                  stream: queryValuationStartupRecord(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<ValuationStartupRecord>
                        columnValuationStartupRecordList = snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children:
                          List.generate(columnValuationStartupRecordList.length,
                              (columnIndex) {
                        final columnValuationStartupRecord =
                            columnValuationStartupRecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: FutureBuilder<List<UsersRecord>>(
                            future: queryUsersRecordOnce(
                              queryBuilder: (usersRecord) => usersRecord.where(
                                'valuation_startup',
                                isEqualTo:
                                    columnValuationStartupRecord.reference,
                              ),
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return const Center(
                                  child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.transparent,
                                      ),
                                    ),
                                  ),
                                );
                              }
                              List<UsersRecord> listTileUsersRecordList =
                                  snapshot.data!;
                              return InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'ANSWER_BANK_ListTile_g3lsyrfs_ON_TAP');
                                  if (listTileUsersRecordList.isNotEmpty) {
                                    logFirebaseEvent('ListTile_navigate_to');

                                    context.pushNamed(
                                      'ShowUsersPage',
                                      queryParameters: {
                                        'title': serializeParam(
                                          columnValuationStartupRecord.name,
                                          ParamType.String,
                                        ),
                                        'users': serializeParam(
                                          listTileUsersRecordList,
                                          ParamType.Document,
                                          true,
                                        ),
                                      }.withoutNulls,
                                      extra: <String, dynamic>{
                                        'users': listTileUsersRecordList,
                                        kTransitionInfoKey: const TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.rightToLeft,
                                        ),
                                      },
                                    );
                                  }
                                },
                                child: Slidable(
                                  endActionPane: ActionPane(
                                    motion: const ScrollMotion(),
                                    extentRatio: 0.25,
                                    children: [
                                      SlidableAction(
                                        label: 'Deletar',
                                        backgroundColor:
                                            FlutterFlowTheme.of(context).error,
                                        icon: FontAwesomeIcons.solidTrashAlt,
                                        onPressed: (_) async {
                                          logFirebaseEvent(
                                              'ANSWER_BANK_SlidableActionWidget_jvim0ux');
                                          logFirebaseEvent(
                                              'SlidableActionWidget_backend_call');
                                          await columnValuationStartupRecord
                                              .reference
                                              .delete();
                                        },
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      columnValuationStartupRecord.name,
                                      style: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    subtitle: Text(
                                      listTileUsersRecordList.isEmpty
                                          ? 'Ninguém respondeu'
                                          : '${valueOrDefault<String>(
                                              listTileUsersRecordList.length
                                                  .toString(),
                                              '0',
                                            )} ${listTileUsersRecordList.length > 1 ? 'responderam' : 'respondeu'}',
                                      style: FlutterFlowTheme.of(context)
                                          .labelSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    dense: false,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'Tem mentores?',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'ANSWER_BANK_Text_7q07magz_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewAnswerWidget(
                                      type: 'question_1',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<Question1Record>>(
                  stream: queryQuestion1Record(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<Question1Record> columnQuestion1RecordList =
                        snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: List.generate(columnQuestion1RecordList.length,
                          (columnIndex) {
                        final columnQuestion1Record =
                            columnQuestion1RecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: FutureBuilder<List<UsersRecord>>(
                            future: queryUsersRecordOnce(
                              queryBuilder: (usersRecord) => usersRecord.where(
                                'question_1',
                                isEqualTo: columnQuestion1Record.reference,
                              ),
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return const Center(
                                  child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.transparent,
                                      ),
                                    ),
                                  ),
                                );
                              }
                              List<UsersRecord> listTileUsersRecordList =
                                  snapshot.data!;
                              return InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'ANSWER_BANK_ListTile_zrj4eri1_ON_TAP');
                                  if (listTileUsersRecordList.isNotEmpty) {
                                    logFirebaseEvent('ListTile_navigate_to');

                                    context.pushNamed(
                                      'ShowUsersPage',
                                      queryParameters: {
                                        'title': serializeParam(
                                          columnQuestion1Record.name,
                                          ParamType.String,
                                        ),
                                        'users': serializeParam(
                                          listTileUsersRecordList,
                                          ParamType.Document,
                                          true,
                                        ),
                                      }.withoutNulls,
                                      extra: <String, dynamic>{
                                        'users': listTileUsersRecordList,
                                        kTransitionInfoKey: const TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.rightToLeft,
                                        ),
                                      },
                                    );
                                  }
                                },
                                child: Slidable(
                                  endActionPane: ActionPane(
                                    motion: const ScrollMotion(),
                                    extentRatio: 0.25,
                                    children: [
                                      SlidableAction(
                                        label: 'Deletar',
                                        backgroundColor:
                                            FlutterFlowTheme.of(context).error,
                                        icon: FontAwesomeIcons.solidTrashAlt,
                                        onPressed: (_) async {
                                          logFirebaseEvent(
                                              'ANSWER_BANK_SlidableActionWidget_nox7k98');
                                          logFirebaseEvent(
                                              'SlidableActionWidget_backend_call');
                                          await columnQuestion1Record.reference
                                              .delete();
                                        },
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      columnQuestion1Record.name,
                                      style: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    subtitle: Text(
                                      listTileUsersRecordList.isEmpty
                                          ? 'Ninguém respondeu'
                                          : '${valueOrDefault<String>(
                                              listTileUsersRecordList.length
                                                  .toString(),
                                              '0',
                                            )} ${listTileUsersRecordList.length > 1 ? 'responderam' : 'respondeu'}',
                                      style: FlutterFlowTheme.of(context)
                                          .labelSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    dense: false,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'Tem Investidor(es) Anjo?',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'ANSWER_BANK_Text_l0cxzody_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewAnswerWidget(
                                      type: 'question_2',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<Question2Record>>(
                  stream: queryQuestion2Record(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<Question2Record> columnQuestion2RecordList =
                        snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: List.generate(columnQuestion2RecordList.length,
                          (columnIndex) {
                        final columnQuestion2Record =
                            columnQuestion2RecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: FutureBuilder<List<UsersRecord>>(
                            future: queryUsersRecordOnce(
                              queryBuilder: (usersRecord) => usersRecord.where(
                                'question_2',
                                isEqualTo: columnQuestion2Record.reference,
                              ),
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return const Center(
                                  child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.transparent,
                                      ),
                                    ),
                                  ),
                                );
                              }
                              List<UsersRecord> listTileUsersRecordList =
                                  snapshot.data!;
                              return InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'ANSWER_BANK_ListTile_x0j52ikz_ON_TAP');
                                  if (listTileUsersRecordList.isNotEmpty) {
                                    logFirebaseEvent('ListTile_navigate_to');

                                    context.pushNamed(
                                      'ShowUsersPage',
                                      queryParameters: {
                                        'title': serializeParam(
                                          columnQuestion2Record.name,
                                          ParamType.String,
                                        ),
                                        'users': serializeParam(
                                          listTileUsersRecordList,
                                          ParamType.Document,
                                          true,
                                        ),
                                      }.withoutNulls,
                                      extra: <String, dynamic>{
                                        'users': listTileUsersRecordList,
                                        kTransitionInfoKey: const TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.rightToLeft,
                                        ),
                                      },
                                    );
                                  }
                                },
                                child: Slidable(
                                  endActionPane: ActionPane(
                                    motion: const ScrollMotion(),
                                    extentRatio: 0.25,
                                    children: [
                                      SlidableAction(
                                        label: 'Deletar',
                                        backgroundColor:
                                            FlutterFlowTheme.of(context).error,
                                        icon: FontAwesomeIcons.solidTrashAlt,
                                        onPressed: (_) async {
                                          logFirebaseEvent(
                                              'ANSWER_BANK_SlidableActionWidget_gjyjoef');
                                          logFirebaseEvent(
                                              'SlidableActionWidget_backend_call');
                                          await columnQuestion2Record.reference
                                              .delete();
                                        },
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      columnQuestion2Record.name,
                                      style: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    subtitle: Text(
                                      listTileUsersRecordList.isEmpty
                                          ? 'Ninguém respondeu'
                                          : '${valueOrDefault<String>(
                                              listTileUsersRecordList.length
                                                  .toString(),
                                              '0',
                                            )} ${listTileUsersRecordList.length > 1 ? 'responderam' : 'respondeu'}',
                                      style: FlutterFlowTheme.of(context)
                                          .labelSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    dense: false,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          'Valuation já validado por algum VC?',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                      Builder(
                        builder: (context) => InkWell(
                          splashColor: Colors.transparent,
                          focusColor: Colors.transparent,
                          hoverColor: Colors.transparent,
                          highlightColor: Colors.transparent,
                          onTap: () async {
                            logFirebaseEvent(
                                'ANSWER_BANK_Text_vxf25uff_ON_TAP');
                            logFirebaseEvent('Text_alert_dialog');
                            await showDialog(
                              context: context,
                              builder: (dialogContext) {
                                return Dialog(
                                  elevation: 0,
                                  insetPadding: EdgeInsets.zero,
                                  backgroundColor: Colors.transparent,
                                  alignment: const AlignmentDirectional(0.0, 0.0)
                                      .resolve(Directionality.of(context)),
                                  child: GestureDetector(
                                    onTap: () => _model
                                            .unfocusNode.canRequestFocus
                                        ? FocusScope.of(context)
                                            .requestFocus(_model.unfocusNode)
                                        : FocusScope.of(context).unfocus(),
                                    child: const NewAnswerWidget(
                                      type: 'question_3',
                                    ),
                                  ),
                                );
                              },
                            ).then((value) => setState(() {}));
                          },
                          child: Text(
                            'Adicionar',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: FlutterFlowTheme.of(context).leve,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                          ),
                        ),
                      ),
                    ].divide(const SizedBox(width: 20.0)),
                  ),
                ),
                StreamBuilder<List<Question3Record>>(
                  stream: queryQuestion3Record(),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 64.0, 0.0, 64.0),
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: SpinKitFadingCube(
                              color: FlutterFlowTheme.of(context).primary,
                              size: 32.0,
                            ),
                          ),
                        ),
                      );
                    }
                    List<Question3Record> columnQuestion3RecordList =
                        snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: List.generate(columnQuestion3RecordList.length,
                          (columnIndex) {
                        final columnQuestion3Record =
                            columnQuestion3RecordList[columnIndex];
                        return Container(
                          width: double.infinity,
                          constraints: const BoxConstraints(
                            minHeight: 75.0,
                          ),
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).abcd,
                          ),
                          child: FutureBuilder<List<UsersRecord>>(
                            future: queryUsersRecordOnce(
                              queryBuilder: (usersRecord) => usersRecord.where(
                                'question_3',
                                isEqualTo: columnQuestion3Record.reference,
                              ),
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return const Center(
                                  child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        Colors.transparent,
                                      ),
                                    ),
                                  ),
                                );
                              }
                              List<UsersRecord> listTileUsersRecordList =
                                  snapshot.data!;
                              return InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  logFirebaseEvent(
                                      'ANSWER_BANK_ListTile_yiak5b8a_ON_TAP');
                                  if (listTileUsersRecordList.isNotEmpty) {
                                    logFirebaseEvent('ListTile_navigate_to');

                                    context.pushNamed(
                                      'ShowUsersPage',
                                      queryParameters: {
                                        'title': serializeParam(
                                          columnQuestion3Record.name,
                                          ParamType.String,
                                        ),
                                        'users': serializeParam(
                                          listTileUsersRecordList,
                                          ParamType.Document,
                                          true,
                                        ),
                                      }.withoutNulls,
                                      extra: <String, dynamic>{
                                        'users': listTileUsersRecordList,
                                        kTransitionInfoKey: const TransitionInfo(
                                          hasTransition: true,
                                          transitionType:
                                              PageTransitionType.rightToLeft,
                                        ),
                                      },
                                    );
                                  }
                                },
                                child: Slidable(
                                  endActionPane: ActionPane(
                                    motion: const ScrollMotion(),
                                    extentRatio: 0.25,
                                    children: [
                                      SlidableAction(
                                        label: 'Deletar',
                                        backgroundColor:
                                            FlutterFlowTheme.of(context).error,
                                        icon: FontAwesomeIcons.solidTrashAlt,
                                        onPressed: (_) async {
                                          logFirebaseEvent(
                                              'ANSWER_BANK_SlidableActionWidget_qz0usae');
                                          logFirebaseEvent(
                                              'SlidableActionWidget_backend_call');
                                          await columnQuestion3Record.reference
                                              .delete();
                                        },
                                      ),
                                    ],
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      columnQuestion3Record.name,
                                      style: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    subtitle: Text(
                                      listTileUsersRecordList.isEmpty
                                          ? 'Ninguém respondeu'
                                          : '${valueOrDefault<String>(
                                              listTileUsersRecordList.length
                                                  .toString(),
                                              '0',
                                            )} ${listTileUsersRecordList.length > 1 ? 'responderam' : 'respondeu'}',
                                      style: FlutterFlowTheme.of(context)
                                          .labelSmall
                                          .override(
                                            fontFamily: 'Readex Pro',
                                            letterSpacing: 0.0,
                                          ),
                                    ),
                                    dense: false,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      }).divide(const SizedBox(height: 4.0)),
                    );
                  },
                ),
              ].divide(const SizedBox(height: 16.0)).around(const SizedBox(height: 16.0)),
            ),
          ),
        ),
      ),
    );
  }
}
